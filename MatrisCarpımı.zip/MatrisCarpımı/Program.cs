﻿using System;

class Program
{
    static void Main()
    {
        // 1. Kullanıcıdan NxN matris boyutunu almak
        Console.Write("Matrisin boyutunu girin (n): ");
        int n = int.Parse(Console.ReadLine());

        // 2. Kullanıcıdan iki matrisin elemanlarını almak
        int[,] matrix1 = new int[n, n];
        int[,] matrix2 = new int[n, n];
        int[,] result = new int[n, n];

        Console.WriteLine("\nBirinci matrisi girin:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write($"matrix1[{i},{j}] = ");
                matrix1[i, j] = int.Parse(Console.ReadLine());
            }
        }

        Console.WriteLine("\nİkinci matrisi girin:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write($"matrix2[{i},{j}] = ");
                matrix2[i, j] = int.Parse(Console.ReadLine());
            }
        }

        // 3. Matris çarpımını yapmak
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                result[i, j] = 0; // Sonuç matrisini sıfırla
                for (int k = 0; k < n; k++)
                {
                    result[i, j] += matrix1[i, k] * matrix2[k, j];
                }
            }
        }

        // 4. Sonuç matrisini ekrana yazdırmak
        Console.WriteLine("\nMatris Çarpımının Sonucu:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write(result[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
