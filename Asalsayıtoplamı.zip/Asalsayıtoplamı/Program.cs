﻿using System;

class PrimeSum
{
    static void Main()
    {
        // Kullanıcıdan N değerini alıyoruz.
        Console.Write("N değerini girin: ");
        int n = int.Parse(Console.ReadLine());

        int sum = 0; // Asal sayıların toplamını tutacak değişken

        // 2'den N'ye kadar olan tüm sayıları kontrol ediyoruz
        for (int i = 2; i <= n; i++)
        {
            if (IsPrime(i)) // Eğer i asal ise
            {
                sum += i; // Asal sayıyı toplama ekliyoruz
                Console.Write(i+" ");// Asal sayıları ekrana yazdırıyoruz
            }
        }

        // Sonucu ekrana yazdırıyoruz
        
        Console.WriteLine($"1'den {n}'ye kadar olan asal sayıların toplamı: {sum}");
    }

    // Bir sayının asal olup olmadığını kontrol eden fonksiyon
    static bool IsPrime(int number)
    {
        if (number < 2) return false; // 2'den küçük sayılar asal değildir

        // 2'den başla ve sayının kareköküne kadar olan sayılarla bölünebilirliğini kontrol et
        for (int i = 2; i * i <= number; i++)
        {
            if (number % i == 0)
            {
                return false; // Eğer sayı herhangi bir sayıya bölünebiliyorsa asal değildir
            }
        }
        return true; // Eğer hiçbir sayıya bölünmüyorsa asal sayıdır
    }
}
