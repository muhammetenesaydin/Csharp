﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Mayın Tarlası Oyununa Hoş Geldiniz!");
        Console.Write("Tablonun boyutunu giriniz (örneğin 5 için 5x5): ");
        int boyut = int.Parse(Console.ReadLine());

        Console.Write("Mayın sayısını giriniz: ");
        int mayinSayisi = int.Parse(Console.ReadLine());

        // Oyun alanı ve mayın yerleşimi
        char[,] tablo = new char[boyut, boyut];
        bool[,] mayinlar = new bool[boyut, boyut];
        Random rand = new Random();

        // Tablonun boş gösterimi
        for (int i = 0; i < boyut; i++)
        {
            for (int j = 0; j < boyut; j++)
            {
                tablo[i, j] = '-';
            }
        }

        // Mayınların rastgele yerleştirilmesi
        int yerlestirilenMayin = 0;
        while (yerlestirilenMayin < mayinSayisi)
        {
            int x = rand.Next(0, boyut);
            int y = rand.Next(0, boyut);

            if (!mayinlar[x, y])
            {
                mayinlar[x, y] = true;
                yerlestirilenMayin++;
            }
        }

        // Oyun döngüsü
        bool oyunBitti = false;
        int acilanHucresayisi = 0;
        int toplamHedef = (boyut * boyut) - mayinSayisi;

        while (!oyunBitti)
        {
            Console.Clear();
            Console.WriteLine("Mayın Tarlası:");
            // Tablonun gösterimi
            for (int i = 0; i < boyut; i++)
            {
                for (int j = 0; j < boyut; j++)
                {
                    Console.Write(tablo[i, j] + " ");
                }
                Console.WriteLine();
            }

            Console.Write("Satır giriniz (0 ile {0} arasında): ", boyut - 1);
            int satir = int.Parse(Console.ReadLine());

            Console.Write("Sütun giriniz (0 ile {0} arasında): ", boyut - 1);
            int sutun = int.Parse(Console.ReadLine());

            // Kullanıcının girdiği hücreyi kontrol et
            if (mayinlar[satir, sutun])
            {
                Console.Clear();
                Console.WriteLine("GAME OVER! Bir mayına bastınız.");
                oyunBitti = true;
            }
            else
            {
                if (tablo[satir, sutun] == '-')
                {
                    tablo[satir, sutun] = '0'; // Açılan hücreyi işaretle
                    acilanHucresayisi++;

                    if (acilanHucresayisi == toplamHedef)
                    {
                        Console.Clear();
                        Console.WriteLine("TEBRİKLER! Tüm güvenli hücreleri açtınız.");
                        oyunBitti = true;
                    }
                }
                else
                {
                    Console.WriteLine("Bu hücreyi zaten açtınız.");
                }
            }
        }
    }
}

