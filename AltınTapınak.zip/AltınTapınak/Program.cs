﻿using System;
using System.Collections.Generic;

namespace MatrisYolBulma
{
    class Program
    {
        // Yönler: Sağ, Sol, Aşağı, Yukarı
        static readonly int[] dx = { 0, 0, 1, -1 };
        static readonly int[] dy = { 1, -1, 0, 0 };

        static void Main(string[] args)
        {
            Console.Write("Matris boyutu n giriniz: ");
            if (!int.TryParse(Console.ReadLine(), out int n) || n <= 0)
            {
                Console.WriteLine("Geçerli bir pozitif tam sayı giriniz.");
                return;
            }

            int[,] matris = OlusturMatris(n);
            YazdirLabirent(matris, n);

            if (matris[0, 0] == 0 || matris[n - 1, n - 1] == 0)
            {
                Console.WriteLine("Yol yok.");
                return;
            }

            int? enKisaYol = EnKisaYoluBul(matris, n);

            if (enKisaYol.HasValue)
            {
                Console.WriteLine($"\nEn Kısa Yol: {enKisaYol.Value} adım");
            }
            else
            {
                Console.WriteLine("\nYol yok.");
            }
        }

        static int[,] OlusturMatris(int n)
        {
            int[,] matris = new int[n, n];
            Random rnd = new Random();

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    matris[i, j] = rnd.Next(0, 2); // 0 veya 1
                }
            }

            return matris;
        }

        static void YazdirLabirent(int[,] matris, int n)
        {
            Console.WriteLine("\nLabirent:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(matris[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        static int? EnKisaYoluBul(int[,] matris, int n)
        {
            bool[,] ziyaretEdildi = new bool[n, n];
            Queue<(int x, int y, int adim)> kuyruk = new Queue<(int, int, int)>();

            // Başlangıç noktası
            kuyruk.Enqueue((0, 0, 0));
            ziyaretEdildi[0, 0] = true;

            while (kuyruk.Count > 0)
            {
                var (x, y, adim) = kuyruk.Dequeue();

                // Hedefe ulaşıldı
                if (x == n - 1 && y == n - 1)
                {
                    return adim;
                }

                // Tüm dört yönde hareket et
                for (int i = 0; i < 4; i++)
                {
                    int yeniX = x + dx[i];
                    int yeniY = y + dy[i];

                    if (YeniKonumGecerli(yeniX, yeniY, n) && !ziyaretEdildi[yeniX, yeniY] && matris[yeniX, yeniY] == 1)
                    {
                        kuyruk.Enqueue((yeniX, yeniY, adim + 1));
                        ziyaretEdildi[yeniX, yeniY] = true;
                    }
                }
            }

            // Yol bulunamadı
            return null;
        }

        static bool YeniKonumGecerli(int x, int y, int n)
        {
            return x >= 0 && y >= 0 && x < n && y < n;
        }
    }
}
/*
Matris boyutu n giriniz: 4

Labirent:
1 0 0 0 
1 1 0 1 
0 1 1 1 
0 0 0 1 

En Kısa Yol: 6 adım



Matris boyutu n giriniz: 3

Labirent:
1 0 0 
0 1 0 
0 0 1 

Yol yok.
 
 */
