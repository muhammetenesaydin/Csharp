﻿using System;

class SpiralMatrix
{
    static void Main()
    {
        // Kullanıcıdan NxN matris boyutunu girmesini istiyoruz.
        Console.Write("Matris boyutunu girin (N x N)(Sadece N'yi gireceksiniz.) : ");
        int n = int.Parse(Console.ReadLine()); // Girilen değeri integer'a çeviriyoruz.

        // NxN boyutunda bir matris oluşturuyoruz.
        int[,] matrix = new int[n, n];

        // Matrisi spiral şekilde dolduran fonksiyonu çağırıyoruz.
        FillSpiralMatrix(matrix, n);

        // Doldurulan matrisi ekrana yazdıran fonksiyonu çağırıyoruz.
        PrintMatrix(matrix, n);
    }

    // Bu fonksiyon, matrisi spiral şekilde doldurur.
    static void FillSpiralMatrix(int[,] matrix, int n)
    {
        int value = 1; // Matrisin içine yerleştirilecek başlangıç değeri.

        // Matrisin sınırlarını belirlemek için dört değişken kullanıyoruz.
        int top = 0; // Üst sınır
        int bottom = n - 1; // Alt sınır
        int left = 0; // Sol sınır
        int right = n - 1; // Sağ sınır

        // Matrisin tamamını spiral olarak doldurana kadar döngü devam eder.
        while (value <= n * n)
        {
            // 1. Adım: Üst satırı soldan sağa doğru dolduruyoruz.
            for (int i = left; i <= right; i++)
                matrix[top, i] = value++; // Üst sıradaki hücreye değer yerleştirilir ve değer bir artırılır.
            top++; // Üst sınır bir alt satıra çekilir.

            // 2. Adım: Sağ sütunu yukarıdan aşağıya doğru dolduruyoruz.
            for (int i = top; i <= bottom; i++)
                matrix[i, right] = value++; // Sağ sütundaki hücreye değer yerleştirilir ve değer bir artırılır.
            right--; // Sağ sınır bir sola çekilir.

            // 3. Adım: Alt satırı sağdan sola doğru dolduruyoruz.
            for (int i = right; i >= left; i--)
                matrix[bottom, i] = value++; // Alt sıradaki hücreye değer yerleştirilir ve değer bir artırılır.
            bottom--; // Alt sınır bir üst satıra çekilir.

            // 4. Adım: Sol sütunu aşağıdan yukarıya doğru dolduruyoruz.
            for (int i = bottom; i >= top; i--)
                matrix[i, left] = value++; // Sol sütundaki hücreye değer yerleştirilir ve değer bir artırılır.
            left++; // Sol sınır bir sağa çekilir.

            // Yukarıdaki dört adım, spiral hareketi tamamlar. Bu işlem matrisi tamamen doldurana kadar devam eder.
        }
    }

    // Bu fonksiyon, matrisi ekrana yazdırır.
    static void PrintMatrix(int[,] matrix, int n)
    {
        // Matrisin satırlarını ve sütunlarını ekrana yazdırmak için iki iç içe döngü kullanıyoruz.
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                // Her hücredeki değeri yazdırıyoruz ve sekme (\t) ile hizalıyoruz.
                Console.Write(matrix[i, j] + "\t");
            }
            // Her satır yazdırıldığında bir alt satıra geçmek için boş bir satır ekliyoruz.
            Console.WriteLine();
        }
    }
}


