using System;
using System.Drawing;
using System.Windows.Forms;

namespace AdamAsmaca_2
{
    public partial class Form1 : Form
    {
        private string[] iller = new string[]
        {
            "Adana", "Ad�yaman", "Afyonkarahisar", "A�r�", "Amasya", "Ankara", "Antalya", "Artvin", "Ayd�n", "Bal�kesir",
            "Bilecik", "Bing�l", "Bitlis", "Bolu", "Burdur", "Bursa", "�anakkale", "�ank�r�", "�orum", "Denizli",
            "Diyarbak�r", "Edirne", "Elaz��", "Erzincan", "Erzurum", "Eski�ehir", "Gaziantep", "Giresun", "G�m��hane", "Hakk�ri",
            "Hatay", "Isparta", "Mersin", "�stanbul", "�zmir", "Kars", "Kastamonu", "Kayseri", "K�rklareli", "K�r�ehir",
            "Kocaeli", "Konya", "K�tahya", "Malatya", "Manisa", "Kahramanmara�", "Mardin", "Mu�la", "Mu�", "Nev�ehir",
            "Ni�de", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas", "Tekirda�", "Tokat",
            "Trabzon", "Tunceli", "�anl�urfa", "U�ak", "Van", "Yozgat", "Zonguldak", "Aksaray", "Bayburt", "Karaman",
            "K�r�kkale", "Batman", "��rnak", "Bart�n", "Ardahan", "I�d�r", "Yalova", "Karab�k", "Kilis", "Osmaniye", "D�zce"
        };

        private string kelime;
        private char[] tahminEdilen;
        private int kalanHak = 6;
        private string yanlisHarfler = "";

        public Form1()
        {
            InitializeComponent();
            kelime = iller[new Random().Next(iller.Length)].ToUpper();
            tahminEdilen = new string('_', kelime.Length).ToCharArray();
            GuncelleKelime();
        }

        private void GuncelleKelime()
        {
            kelimeLabel.Text = string.Join(" ", tahminEdilen); // Alt �izgiler aras�nda bo�luklar
            durumLabel.Text = $"Kalan Hak: {kalanHak}";
            yanlisLabel.Text = $"Yanl�� Harfler: {yanlisHarfler}"; // Yanl�� harfleri g�ster
            GuncelleResim();
        }

        private void GuncelleResim()
        {
            Bitmap bmp = new Bitmap(200, 200);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.White);
                Pen kalem = new Pen(Color.Black, 2);

                // Stand
                g.DrawLine(kalem, 10, 190, 100, 190);
                g.DrawLine(kalem, 55, 190, 55, 20);
                g.DrawLine(kalem, 55, 20, 130, 20);
                g.DrawLine(kalem, 130, 20, 130, 50);

                if (kalanHak <= 5)
                    g.DrawEllipse(kalem, 110, 50, 40, 40); // Kafa
                if (kalanHak <= 4)
                    g.DrawLine(kalem, 130, 90, 130, 140); // G�vde
                if (kalanHak <= 3)
                    g.DrawLine(kalem, 130, 100, 110, 120); // Sol Kol
                if (kalanHak <= 2)
                    g.DrawLine(kalem, 130, 100, 150, 120); // Sa� Kol
                if (kalanHak <= 1)
                    g.DrawLine(kalem, 130, 140, 110, 170); // Sol Bacak
                if (kalanHak <= 0)
                    g.DrawLine(kalem, 130, 140, 150, 170); // Sa� Bacak
            }
            adamPictureBox.Image = bmp;
        }

        private void tahminButton_Click(object sender, EventArgs e)
        {
            if (harfTextBox.Text.Length == 1)
            {
                char harf = harfTextBox.Text.ToUpper()[0];
                bool bulundu = false;

                for (int i = 0; i < kelime.Length; i++)
                {
                    if (kelime[i] == harf)
                    {
                        tahminEdilen[i] = harf;
                        bulundu = true;
                    }
                }

                if (!bulundu)
                {
                    if (!yanlisHarfler.Contains(harf))
                    {
                        yanlisHarfler += harf + " ";
                        kalanHak--;
                    }
                }

                harfTextBox.Clear();
                GuncelleKelime();

                if (kalanHak <= 0)
                {
                    MessageBox.Show("Kaybettiniz! Kelime: " + kelime);
                    this.Close();
                }
                else if (!new string(tahminEdilen).Contains('_'))
                {
                    MessageBox.Show("Tebrikler, kazand�n�z!");
                    this.Close();
                }
            }
        }
    }
}