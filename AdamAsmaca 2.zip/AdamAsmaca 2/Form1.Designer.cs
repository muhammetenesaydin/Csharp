﻿namespace AdamAsmaca_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            kelimeLabel = new Label();
            harfTextBox = new TextBox();
            tahminButton = new Button();
            durumLabel = new Label();
            adamPictureBox = new PictureBox();
            yanlisLabel = new Label();
            ((System.ComponentModel.ISupportInitialize)adamPictureBox).BeginInit();
            SuspendLayout();
            // 
            // kelimeLabel
            // 
            kelimeLabel.AutoSize = true;
            kelimeLabel.BackColor = Color.Lime;
            kelimeLabel.Location = new Point(96, 101);
            kelimeLabel.Name = "kelimeLabel";
            kelimeLabel.Size = new Size(0, 20);
            kelimeLabel.TabIndex = 0;
            // 
            // harfTextBox
            // 
            harfTextBox.Location = new Point(39, 171);
            harfTextBox.MaxLength = 1;
            harfTextBox.Name = "harfTextBox";
            harfTextBox.Size = new Size(125, 27);
            harfTextBox.TabIndex = 1;
            // 
            // tahminButton
            // 
            tahminButton.Location = new Point(57, 204);
            tahminButton.Name = "tahminButton";
            tahminButton.Size = new Size(94, 29);
            tahminButton.TabIndex = 2;
            tahminButton.Text = "Tahmin Et";
            tahminButton.UseVisualStyleBackColor = true;
            tahminButton.Click += tahminButton_Click;
            // 
            // durumLabel
            // 
            durumLabel.AutoSize = true;
            durumLabel.Location = new Point(96, 270);
            durumLabel.Name = "durumLabel";
            durumLabel.Size = new Size(0, 20);
            durumLabel.TabIndex = 3;
            // 
            // adamPictureBox
            // 
            adamPictureBox.Location = new Point(462, 35);
            adamPictureBox.Name = "adamPictureBox";
            adamPictureBox.Size = new Size(270, 299);
            adamPictureBox.SizeMode = PictureBoxSizeMode.AutoSize;
            adamPictureBox.TabIndex = 5;
            adamPictureBox.TabStop = false;
            // 
            // yanlisLabel
            // 
            yanlisLabel.AutoSize = true;
            yanlisLabel.BackColor = Color.Yellow;
            yanlisLabel.Location = new Point(266, 121);
            yanlisLabel.Name = "yanlisLabel";
            yanlisLabel.Size = new Size(0, 20);
            yanlisLabel.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ScrollBar;
            ClientSize = new Size(808, 450);
            Controls.Add(yanlisLabel);
            Controls.Add(adamPictureBox);
            Controls.Add(durumLabel);
            Controls.Add(tahminButton);
            Controls.Add(harfTextBox);
            Controls.Add(kelimeLabel);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)adamPictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label kelimeLabel;
        private TextBox harfTextBox;
        private Button tahminButton;
        private Label durumLabel;
        private PictureBox adamPictureBox;
        private Label yanlisLabel;
    }
}
