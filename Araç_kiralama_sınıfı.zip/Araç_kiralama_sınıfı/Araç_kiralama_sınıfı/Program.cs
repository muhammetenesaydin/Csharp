﻿using System;

class KiralikArac
{
    // Özellikler
    public string Plaka { get; set; }
    public decimal GunlukUcret { get; set; }
    public bool MusaitMi { get; private set; }

    // Yapıcı Metot
    public KiralikArac(string plaka, decimal gunlukUcret)
    {
        Plaka = plaka;
        GunlukUcret = gunlukUcret;
        MusaitMi = true; // Varsayılan olarak araç müsait
    }

    // Araç kiralama metodu
    public void AraciKirala()
    {
        if (MusaitMi)
        {
            MusaitMi = false;
            Console.WriteLine($"Araç ({Plaka}) başarıyla kiralandı.");
        }
        else
        {
            Console.WriteLine($"Araç ({Plaka}) zaten kirada.");
        }
    }

    // Araç teslim etme metodu
    public void AraciTeslimEt()
    {
        if (!MusaitMi)
        {
            MusaitMi = true;
            Console.WriteLine($"Araç ({Plaka}) başarıyla teslim edildi.");
        }
        else
        {
            Console.WriteLine($"Araç ({Plaka}) zaten müsait durumda.");
        }
    }
}

// Kullanıcı ile etkileşimli program
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Araç plakası girin:");
        string plaka = Console.ReadLine();

        Console.WriteLine("Günlük kiralama ücretini girin (TL):");
        decimal gunlukUcret = Convert.ToDecimal(Console.ReadLine());

        // Kiralık araç nesnesini oluştur
        KiralikArac arac = new KiralikArac(plaka, gunlukUcret);

        bool devamEt = true;
        while (devamEt)
        {
            Console.WriteLine("\nBir işlem seçin:");
            Console.WriteLine("1 - Aracı Kirala");
            Console.WriteLine("2 - Aracı Teslim Et");
            Console.WriteLine("3 - Araç Bilgilerini Görüntüle");
            Console.WriteLine("4 - Çıkış");

            int secim;
            if (!int.TryParse(Console.ReadLine(), out secim))
            {
                Console.WriteLine("Geçersiz giriş. Lütfen bir sayı girin.");
                continue;
            }

            switch (secim)
            {
                case 1:
                    arac.AraciKirala();
                    break;
                case 2:
                    arac.AraciTeslimEt();
                    break;
                case 3:
                    Console.WriteLine("\nAraç Bilgileri:");
                    Console.WriteLine($"Plaka: {arac.Plaka}");
                    Console.WriteLine($"Günlük Ücret: {arac.GunlukUcret} TL");
                    Console.WriteLine($"Durum: {(arac.MusaitMi ? "Müsait" : "Kirada")}");
                    break;
                case 4:
                    devamEt = false;
                    Console.WriteLine("Programdan çıkılıyor...");
                    break;
                default:
                    Console.WriteLine("Geçersiz seçim. Lütfen 1-4 arasında bir değer girin.");
                    break;
            }
        }
    }
}
