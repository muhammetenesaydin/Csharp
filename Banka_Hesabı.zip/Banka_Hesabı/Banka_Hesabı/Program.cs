﻿using System;

public class BankaHesabi
{
    private string hesapNumarasi;
    private decimal bakiye;

    public BankaHesabi(string hesapNumarasi, decimal ilkBakiye)
    {
        this.hesapNumarasi = hesapNumarasi;
        this.bakiye = ilkBakiye;
    }

    public string HesapNumarasi
    {
        get { return hesapNumarasi; }
    }

    public decimal Bakiye
    {
        get { return bakiye; }
        private set { bakiye = value; }
    }

    public void ParaYatir(decimal miktar)
    {
        if (miktar > 0)
        {
            Bakiye += miktar;
            Console.WriteLine($"Hesap {HesapNumarasi}'ya {miktar} TL yatırıldı. Yeni bakiye: {Bakiye} TL");
        }
        else
        {
            Console.WriteLine("Yatırılacak miktar 0'dan büyük olmalıdır.");
        }
    }

    public void ParaCek(decimal miktar)
    {
        if (miktar > 0 && Bakiye >= miktar)
        {
            Bakiye -= miktar;
            Console.WriteLine($"Hesap {HesapNumarasi}'dan {miktar} TL çekildi. Yeni bakiye: {Bakiye} TL");
        }
        else if (Bakiye < miktar)
        {
            Console.WriteLine("Bakiye yetersiz.");
        }
        else
        {
            Console.WriteLine("Çekilecek miktar 0'dan büyük olmalıdır.");
        }
    }
}

class Program
{
    static void Main()
    {
        BankaHesabi hesap = new BankaHesabi("123456789", 1000);
        bool devamEt = true;

        while (devamEt)
        {
            Console.WriteLine($"Hesap {hesap.HesapNumarasi}'nın bakiyesi: {hesap.Bakiye} TL");
            Console.WriteLine("Bir işlem seçin:");
            Console.WriteLine("1 - Para Yatır");
            Console.WriteLine("2 - Para Çek");
            Console.WriteLine("3 - Çıkış");

            int secim = Convert.ToInt32(Console.ReadLine());

            switch (secim)
            {
                case 1:
                    Console.WriteLine("Hesaba yatırmak istediğiniz miktarı girin:");
                    decimal yatirilacakMiktar = Convert.ToDecimal(Console.ReadLine());
                    hesap.ParaYatir(yatirilacakMiktar);
                    Console.WriteLine($"{yatirilacakMiktar} TL hesaba yatırıldı.");
                    break;

                case 2:
                    Console.WriteLine("Hesaptan çekmek istediğiniz miktarı girin:");
                    decimal cekilecekMiktar = Convert.ToDecimal(Console.ReadLine());
                    hesap.ParaCek(cekilecekMiktar);
                    Console.WriteLine($"{cekilecekMiktar} TL hesaptan çekildi.");
                    break;

                case 3:
                    devamEt = false;
                    Console.WriteLine("Çıkış yapılıyor...");
                    break;

                default:
                    Console.WriteLine("Geçersiz bir seçim yaptınız. Tekrar deneyin.");
                    break;
            }

            Console.WriteLine(); // Görsel bir ayrım için boşluk bırakıyoruz.
        }
    }
}
