﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ödevler2
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}

/*  
    #######################################



1. Banka Hesabı Yönetim Sistemi

using System;

namespace BankAccountManagement
{
    // Soyut Hesap sınıfı
    public abstract class Hesap
    {
        public string HesapNo { get; set; }
        public decimal Bakiye { get; protected set; }

        public Hesap(string hesapNo, decimal bakiye)
        {
            HesapNo = hesapNo;
            Bakiye = bakiye;
        }

        public abstract void ParaYatir(decimal miktar);
        public abstract void ParaCek(decimal miktar);
    }

    // BirikimHesabi sınıfı
    public class BirikimHesabi : Hesap, IBankaHesabi
    {
        public decimal FaizOrani { get; set; }
        public DateTime HesapAcilisTarihi { get; set; }

        public BirikimHesabi(string hesapNo, decimal bakiye, decimal faizOrani) : base(hesapNo, bakiye)
        {
            FaizOrani = faizOrani;
            HesapAcilisTarihi = DateTime.Now;
        }

        public override void ParaYatir(decimal miktar)
        {
            Bakiye += miktar + (miktar * FaizOrani / 100);
        }

        public override void ParaCek(decimal miktar)
        {
            if (miktar <= Bakiye)
            {
                Bakiye -= miktar;
            }
            else
            {
                throw new InvalidOperationException("Yetersiz bakiye");
            }
        }

        public void HesapOzeti()
        {
            Console.WriteLine($"Hesap No: {HesapNo}, Bakiye: {Bakiye}, Açılış Tarihi: {HesapAcilisTarihi}");
        }
    }

    // VadesizHesap sınıfı
    public class VadesizHesap : Hesap, IBankaHesabi
    {
        public DateTime HesapAcilisTarihi { get; set; }
        private const decimal IslemUcreti = 5.0m;

        public VadesizHesabi(string hesapNo, decimal bakiye) : base(hesapNo, bakiye)
        {
            HesapAcilisTarihi = DateTime.Now;
        }

        public override void ParaYatir(decimal miktar)
        {
            Bakiye += miktar;
        }

        public override void ParaCek(decimal miktar)
        {
            if (miktar + IslemUcreti <= Bakiye)
            {
                Bakiye -= miktar + IslemUcreti;
            }
            else
            {
                throw new InvalidOperationException("Yetersiz bakiye");
            }
        }

        public void HesapOzeti()
        {
            Console.WriteLine($"Hesap No: {HesapNo}, Bakiye: {Bakiye}, Açılış Tarihi: {HesapAcilisTarihi}");
        }
    }

    // IBankaHesabi arayüzü
    public interface IBankaHesabi
    {
        DateTime HesapAcilisTarihi { get; set; }
        void HesapOzeti();
    }

    class Program
    {
        static void Main(string[] args)
        {
            BirikimHesabi birikimHesabi = new BirikimHesabi("12345", 1000, 5);
            birikimHesabi.ParaYatir(500);
            birikimHesabi.HesapOzeti();

            VadesizHesap vadesizHesap = new VadesizHesap("67890", 2000);
            vadesizHesap.ParaCek(300);
            vadesizHesap.HesapOzeti();
        }
    }
}



    #################################################



2. Mağaza Yönetim Sistemi

using System;
using System.Collections.Generic;

namespace StoreManagement
{
    // Soyut Urun sınıfı
    public abstract class Urun
    {
        public string Ad { get; set; }
        public decimal Fiyat { get; set; }

        public Urun(string ad, decimal fiyat)
        {
            Ad = ad;
            Fiyat = fiyat;
        }

        public abstract decimal HesaplaOdeme();
        public abstract void BilgiYazdir();
    }

    // Kitap sınıfı
    public class Kitap : Urun
    {
        public Kitap(string ad, decimal fiyat) : base(ad, fiyat) { }

        public override decimal HesaplaOdeme()
        {
            return Fiyat * 1.10m; // %10 vergi
        }

        public override void BilgiYazdir()
        {
            Console.WriteLine($"Kitap: {Ad}, Fiyat: {Fiyat}, Ödenecek Tutar: {HesaplaOdeme()}");
        }
    }

    // Elektronik sınıfı
    public class Elektronik : Urun
    {
        public Elektronik(string ad, decimal fiyat) : base(ad, fiyat) { }

        public override decimal HesaplaOdeme()
        {
            return Fiyat * 1.25m; // %25 vergi
        }

        public override void BilgiYazdir()
        {
            Console.WriteLine($"Elektronik: {Ad}, Fiyat: {Fiyat}, Ödenecek Tutar: {HesaplaOdeme()}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Urun> urunler = new List<Urun>
            {
                new Kitap("1984", 30),
                new Elektronik("Laptop", 1000)
            };

            foreach (var urun in urunler)
            {
                urun.BilgiYazdir();
            }
        }
    }
}
3. Yayıncı ve Abone Sistemi (Observer Design Pattern)
csharp
Copy
using System;
using System.Collections.Generic;

namespace ObserverPattern
{
    // IYayinci arayüzü
    public interface IYayinci
    {
        void AboneEkle(IAbone abone);
        void AboneCikar(IAbone abone);
        void AboneListele();
    }

    // IAbone arayüzü
    public interface IAbone
    {
        void BilgiAl(string mesaj);
    }

    // Yayinci sınıfı
    public class Yayinci : IYayinci
    {
        private List<IAbone> aboneler = new List<IAbone>();

        public void AboneEkle(IAbone abone)
        {
            aboneler.Add(abone);
        }

        public void AboneCikar(IAbone abone)
        {
            aboneler.Remove(abone);
        }

        public void AboneListele()
        {
            foreach (var abone in aboneler)
            {
                abone.BilgiAl("Yeni güncelleme!");
            }
        }

        public void Guncelle()
        {
            AboneListele();
        }
    }

    // Abone sınıfı
    public class Abone : IAbone
    {
        public string Ad { get; set; }

        public Abone(string ad)
        {
            Ad = ad;
        }

        public void BilgiAl(string mesaj)
        {
            Console.WriteLine($"{Ad} bilgilendirildi: {mesaj}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Yayinci yayinci = new Yayinci();
            Abone abone1 = new Abone("Abone1");
            Abone abone2 = new Abone("Abone2");

            yayinci.AboneEkle(abone1);
            yayinci.AboneEkle(abone2);

            yayinci.Guncelle();
        }
    }
}

*/
