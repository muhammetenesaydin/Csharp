﻿using System;

namespace CarRentalSystem
{
    public class Transaction
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Date { get; set; }
        public string Address { get; set; }

        public void Confirmation()
        {
            Console.WriteLine("Transaction confirmed.");
        }

        public void Update()
        {
            Console.WriteLine("Transaction updated.");
        }
    }

    public class Reservation
    {
        public int Id { get; set; }
        public string Details { get; set; }
        public string List { get; set; }

        public void Notifies()
        {
            Console.WriteLine("Reservation notification sent.");
        }
    }

    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Contact { get; set; }
        public string Address { get; set; }

        public void VerifyAccount()
        {
            Console.WriteLine("Account verified.");
        }
    }

    public class RentingOwner
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ContactNum { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public void ProcessDebit()
        {
            Console.WriteLine("Debit processed.");
        }

        private void Update()
        {
            Console.WriteLine("Owner details updated.");
        }
    }

    public class Car
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Data { get; set; }
        public string Age { get; set; }
        public string OrderType { get; set; }
    }

    public class Payment
    {
        public int Id { get; set; }
        public int CardNumber { get; set; }
        public string Amount { get; set; }

        public void ProcessPayment()
        {
            Console.WriteLine($"Payment of {Amount} processed.");
        }
    }

    public class Rentals
    {
        public int Id { get; set; }
        public string Names { get; set; }
        public string Price { get; set; }

        public void Add()
        {
            Console.WriteLine("Rental added.");
        }

        public void Update()
        {
            Console.WriteLine("Rental updated.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Example usage
            var customer = new Customer
            {
                Id = 1,
                Name = "John Doe",
                Contact = "123-456-7890",
                Address = "123 Main St"
            };

            var car = new Car
            {
                Id = 1,
                Name = "Toyota Corolla",
                Data = "2023",
                Age = "New",
                OrderType = "Rent"
            };

            var payment = new Payment
            {
                Id = 1,
                CardNumber = 123456789,
                Amount = "100.00"
            };

            var transaction = new Transaction
            {
                Id = 1,
                Name = "Rental Transaction",
                Date = "2023-10-01",
                Address = "123 Main St"
            };

            var reservation = new Reservation
            {
                Id = 1,
                Details = "Car Rental",
                List = "Toyota Corolla"
            };

            var rentingOwner = new RentingOwner
            {
                Id = 1,
                Name = "Jane Doe",
                ContactNum = "987-654-3210",
                Username = "jane_doe",
                Password = "password"
            };

            var rentals = new Rentals
            {
                Id = 1,
                Names = "John Doe",
                Price = "100.00"
            };

            // Perform actions
            customer.VerifyAccount();
            payment.ProcessPayment();
            transaction.Confirmation();
            reservation.Notifies();
            rentingOwner.ProcessDebit();
            rentals.Add();
        }
    }
}