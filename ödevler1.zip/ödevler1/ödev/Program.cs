﻿using System;

namespace UniversitySystem
{
    public class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int PostalCode { get; set; }
        public string Country { get; set; }

        private bool Validate()
        {
            // Validation logic here
            return !string.IsNullOrEmpty(Street) && !string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(State) && PostalCode > 0 && !string.IsNullOrEmpty(Country);
        }

        public string OutputAsLabel()
        {
            return $"{Street}, {City}, {State}, {PostalCode}, {Country}";
        }
    }

    public class Person
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public Address Address { get; set; }

        public void PurchaseParkingPass()
        {
            // Logic to purchase parking pass
            Console.WriteLine($"{Name} has purchased a parking pass.");
        }
    }

    public class Student : Person
    {
        public int StudentNumber { get; set; }
        public int AverageMark { get; set; }

        public bool IsEligibleToEnroll(string course)
        {
            // Logic to check eligibility
            return AverageMark >= 50; // Example eligibility criteria
        }

        public int GetSeminarsTaken()
        {
            // Logic to get seminars taken
            return 5; // Placeholder
        }
    }

    public class Professor : Person
    {
        private int Salary { get; set; }
        public int StaffNumber { get; set; }
        private int YearsOfService { get; set; }
        public int NumberOfClasses { get; set; }

        public void Supervise(Student student)
        {
            // Logic to supervise a student
            Console.WriteLine($"{Name} is supervising {student.Name}.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Example usage
            var address = new Address
            {
                Street = "123 Main St",
                City = "Anytown",
                State = "CA",
                PostalCode = 12345,
                Country = "USA"
            };

            var student = new Student
            {
                Name = "John Doe",
                StudentNumber = 12345,
                AverageMark = 85,
                Address = address
            };

            var professor = new Professor
            {
                Name = "Dr. Smith",
                StaffNumber = 54321,
                NumberOfClasses = 3,
                Address = address
            };

            professor.Supervise(student);
            student.PurchaseParkingPass();

            Console.WriteLine($"Student {student.Name} is eligible to enroll: {student.IsEligibleToEnroll("Math")}");
            Console.WriteLine($"Student {student.Name} has taken {student.GetSeminarsTaken()} seminars.");
        }
    }
}