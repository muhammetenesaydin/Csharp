﻿
/*

#########################################

    Overloading


1.1.Matematiksel İşlemleri Çeşitlendiren Bir Fonksiyon

using System;

namespace MathOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Add(2, 3)); // 5
            Console.WriteLine(Add(2, 3, 4)); // 9
            Console.WriteLine(Add(new int[] { 1, 2, 3, 4 })); // 10
        }

        static int Add(int a, int b)
        {
            return a + b;
        }

        static int Add(int a, int b, int c)
        {
            return a + b + c;
        }

        static int Add(int[] numbers)
        {
            int sum = 0;
            foreach (int num in numbers)
            {
                sum += num;
            }
            return sum;
        }
    }
}

    
1.2. Farklı Şekillerin Alanını Hesaplayan Bir Fonksiyon

using System;

namespace ShapeAreas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(CalculateArea(5)); // 25
            Console.WriteLine(CalculateArea(4, 6)); // 24
            Console.WriteLine(CalculateArea(3.0)); // ~28.27
        }

        static double CalculateArea(double side)
        {
            return side * side; // Square
        }

        static double CalculateArea(double length, double width)
        {
            return length * width; // Rectangle
        }

        static double CalculateArea(double radius)
        {
            return Math.PI * radius * radius; // Circle
        }
    }
}
1.3. Zaman Farkını Farklı Formatlarda Hesaplama

using System;

namespace TimeDifference
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime date1 = new DateTime(2023, 10, 1);
            DateTime date2 = new DateTime(2023, 10, 10);

            Console.WriteLine(CalculateDifference(date1, date2)); // 9 days
            Console.WriteLine(CalculateDifference(date1, date2, "hours")); // 216 hours
            var diff = CalculateDifference(date1, date2, "detailed");
            Console.WriteLine($"{diff.Years} years, {diff.Months} months, {diff.Days} days");
        }

        static int CalculateDifference(DateTime date1, DateTime date2)
        {
            return (date2 - date1).Days;
        }

        static int CalculateDifference(DateTime date1, DateTime date2, string format)
        {
            if (format == "hours")
            {
                return (int)(date2 - date1).TotalHours;
            }
            return 0;
        }

        static (int Years, int Months, int Days) CalculateDifference(DateTime date1, DateTime date2, string format)
        {
            if (format == "detailed")
            {
                int years = date2.Year - date1.Year;
                int months = date2.Month - date1.Month;
                int days = date2.Day - date1.Day;

                if (days < 0)
                {
                    months--;
                    days += DateTime.DaysInMonth(date1.Year, date1.Month);
                }

                if (months < 0)
                {
                    years--;
                    months += 12;
                }

                return (years, months, days);
            }
            return (0, 0, 0);
        }
    }
}


    ##############################################################
    Tek Boyutlu ve Çift Boyutlu İndeksleyiciler


2.1. Özel Bir Kitaplık Yönetim Sistemi

using System;

namespace LibraryManagement
{
    class Library
    {
        private string[] books;

        public Library(int size)
        {
            books = new string[size];
        }

        public string this[int index]
        {
            get
            {
                if (index >= 0 && index < books.Length)
                    return books[index];
                else
                    throw new IndexOutOfRangeException("Invalid index");
            }
            set
            {
                if (index >= 0 && index < books.Length)
                    books[index] = value;
                else
                    throw new IndexOutOfRangeException("Invalid index");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Library lib = new Library(5);
            lib[0] = "Book 1";
            Console.WriteLine(lib[0]); // Book 1
        }
    }
}
2.2. Bir Öğrenci Not Sistemi
csharp
Copy
using System;
using System.Collections.Generic;

namespace StudentGrades
{
    class Student
    {
        private Dictionary<string, int> grades = new Dictionary<string, int>();

        public int this[string subject]
        {
            get
            {
                if (grades.ContainsKey(subject))
                    return grades[subject];
                else
                    throw new KeyNotFoundException("Subject not found");
            }
            set
            {
                grades[subject] = value;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            student["Math"] = 90;
            Console.WriteLine(student["Math"]); // 90
        }
    }
}
2.3. Bir Satranç Tahtası Durumu
csharp
Copy
using System;

namespace ChessBoard
{
    class ChessBoard
    {
        private string[,] board = new string[8, 8];

        public string this[int row, int col]
        {
            get
            {
                if (row >= 0 && row < 8 && col >= 0 && col < 8)
                    return board[row, col] ?? "Empty";
                else
                    throw new IndexOutOfRangeException("Invalid position");
            }
            set
            {
                if (row >= 0 && row < 8 && col >= 0 && col < 8)
                    board[row, col] = value;
                else
                    throw new IndexOutOfRangeException("Invalid position");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ChessBoard cb = new ChessBoard();
            cb[0, 0] = "Rook";
            Console.WriteLine(cb[0, 0]); // Rook
        }
    }
}
2.4. Çok Katmanlı Bir Otopark Sistemi
csharp
Copy
using System;

namespace ParkingSystem
{
    class ParkingLot
    {
        private string[,] spots;

        public ParkingLot(int floors, int spotsPerFloor)
        {
            spots = new string[floors, spotsPerFloor];
        }

        public string this[int floor, int spot]
        {
            get
            {
                if (floor >= 0 && floor < spots.GetLength(0) && spot >= 0 && spot < spots.GetLength(1))
                    return spots[floor, spot] ?? "Empty";
                else
                    throw new IndexOutOfRangeException("Invalid spot");
            }
            set
            {
                if (floor >= 0 && floor < spots.GetLength(0) && spot >= 0 && spot < spots.GetLength(1))
                    spots[floor, spot] = value;
                else
                    throw new IndexOutOfRangeException("Invalid spot");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ParkingLot pl = new ParkingLot(3, 10);
            pl[0, 0] = "ABC123";
            Console.WriteLine(pl[0, 0]); // ABC123
        }
    }
}

    ##########################################################################
    Struct


3.1. Zaman İşlemleri
csharp
Copy
using System;

namespace TimeOperations
{
    struct Time
    {
        public int Hour { get; }
        public int Minute { get; }

        public Time(int hour, int minute)
        {
            Hour = hour >= 0 && hour < 24 ? hour : 0;
            Minute = minute >= 0 && minute < 60 ? minute : 0;
        }

        public int TotalMinutes()
        {
            return Hour * 60 + Minute;
        }

        public int Difference(Time other)
        {
            return Math.Abs(this.TotalMinutes() - other.TotalMinutes());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Time t1 = new Time(14, 30);
            Time t2 = new Time(16, 45);
            Console.WriteLine(t1.Difference(t2)); // 135
        }
    }
}
3.2. Karmaşık Sayı Hesaplama
csharp
Copy
using System;

namespace ComplexNumbers
{
    struct Complex
    {
        public double Real { get; }
        public double Imaginary { get; }

        public Complex(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }

        public Complex Add(Complex other)
        {
            return new Complex(this.Real + other.Real, this.Imaginary + other.Imaginary);
        }

        public Complex Subtract(Complex other)
        {
            return new Complex(this.Real - other.Real, this.Imaginary - other.Imaginary);
        }

        public override string ToString()
        {
            return $"{Real} + {Imaginary}i";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Complex c1 = new Complex(3, 4);
            Complex c2 = new Complex(1, 2);
            Console.WriteLine(c1.Add(c2)); // 4 + 6i
        }
    }
}
3.3. GPS Konum Mesafesi
csharp
Copy
using System;

namespace GPSDistance
{
    struct GPSLocation
    {
        public double Latitude { get; }
        public double Longitude { get; }

        public GPSLocation(double latitude, double longitude)
        {
            Latitude = latitude;
            Longitude = longitude;
        }

        public double DistanceTo(GPSLocation other)
        {
            var R = 6371; // Earth radius in km
            var dLat = ToRadians(other.Latitude - this.Latitude);
            var dLon = ToRadians(other.Longitude - this.Longitude);
            var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                    Math.Cos(ToRadians(this.Latitude)) * Math.Cos(ToRadians(other.Latitude)) *
                    Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
            var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            return R * c;
        }

        private double ToRadians(double angle)
        {
            return Math.PI * angle / 180.0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            GPSLocation loc1 = new GPSLocation(52.2296756, 21.0122287);
            GPSLocation loc2 = new GPSLocation(41.8919300, 12.5113300);
            Console.WriteLine(loc1.DistanceTo(loc2)); // Distance in km
        }
    }
}


    #########################################
    Enum


4.1. Trafik Işığı Durumu

csharp
Copy
using System;

namespace TrafficLight
{
    enum TrafficLightState
    {
        Red,
        Yellow,
        Green
    }

    class TrafficLight
    {
        public TrafficLightState State { get; set; }

        public string GetAction()
        {
            switch (State)
            {
                case TrafficLightState.Red:
                    return "Stop";
                case TrafficLightState.Yellow:
                    return "Caution";
                case TrafficLightState.Green:
                    return "Go";
                default:
                    return "Unknown";
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            TrafficLight tl = new TrafficLight { State = TrafficLightState.Red };
            Console.WriteLine(tl.GetAction()); // Stop
        }
    }
}
4.2. Hava Durumu Tahmini
csharp
Copy
using System;

namespace WeatherForecast
{
    enum WeatherType
    {
        Sunny,
        Rainy,
        Cloudy,
        Stormy
    }

    class Weather
    {
        public WeatherType Type { get; set; }

        public string GetAdvice()
        {
            switch (Type)
            {
                case WeatherType.Sunny:
                    return "Wear sunscreen";
                case WeatherType.Rainy:
                    return "Take an umbrella";
                case WeatherType.Cloudy:
                    return "It might rain";
                case WeatherType.Stormy:
                    return "Stay indoors";
                default:
                    return "Unknown weather";
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Weather weather = new Weather { Type = WeatherType.Rainy };
            Console.WriteLine(weather.GetAdvice()); // Take an umbrella
        }
    }
}
4.3. Çalışan Rolleri ve Maaş Hesaplama
csharp
Copy
using System;

namespace EmployeeRoles
{
    enum EmployeeRole
    {
        Manager,
        Developer,
        Designer,
        Tester
    }

    class Employee
    {
        public EmployeeRole Role { get; set; }

        public double CalculateSalary()
        {
            switch (Role)
            {
                case EmployeeRole.Manager:
                    return 5000;
                case EmployeeRole.Developer:
                    return 4000;
                case EmployeeRole.Designer:
                    return 3500;
                case EmployeeRole.Tester:
                    return 3000;
                default:
                    return 0;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee { Role = EmployeeRole.Developer };
            Console.WriteLine(emp.CalculateSalary()); // 4000
        }
    }
}

*/







