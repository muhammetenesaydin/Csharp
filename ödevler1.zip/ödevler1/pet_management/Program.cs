﻿using System;

namespace PetManagementSystem
{
    public class Owner
    {
        public string Name { get; set; }
        public string ContactInfo { get; set; }
    }

    public class Animal
    {
        public string Type { get; set; }
    }

    public class PetInformation
    {
        public string Breed { get; set; }
        public string Color { get; set; }
    }

    public class Pet
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public Owner Owner { get; set; }
        public Animal Type { get; set; }
        public PetInformation PetInfo { get; set; }

        public void Feed()
        {
            Console.WriteLine($"{Name} has been fed.");
        }

        public bool IsHerbivore()
        {
            // Logic to determine if the pet is herbivore
            return Type.Type == "Rabbit"; // Example logic
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Example usage
            var owner = new Owner
            {
                Name = "John Doe",
                ContactInfo = "123-456-7890"
            };

            var animal = new Animal
            {
                Type = "Dog"
            };

            var petInfo = new PetInformation
            {
                Breed = "Golden Retriever",
                Color = "Golden"
            };

            var pet = new Pet
            {
                Id = "PET123",
                Name = "Buddy",
                Age = 3,
                Owner = owner,
                Type = animal,
                PetInfo = petInfo
            };

            pet.Feed();
            bool isHerbivore = pet.IsHerbivore();
            Console.WriteLine($"Is {pet.Name} a herbivore? {isHerbivore}");
        }
    }
}