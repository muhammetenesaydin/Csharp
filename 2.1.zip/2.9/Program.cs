﻿using System;

public class AsteroidMining
{
    public static int[,] GetEnergyGridFromUser()
    {
        Console.Write("Asteroit ızgarasının boyutunu giriniz (N): ");
        int n = int.Parse(Console.ReadLine());

        int[,] energyGrid = new int[n, n];

        Console.WriteLine($"\n{n}x{n} ızgara için her hücredeki enerji değerlerini giriniz:");
        Console.WriteLine("Her sayıdan sonra Enter tuşuna basın.");

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write($"Konum ({i},{j}) için enerji değeri: ");
                energyGrid[i, j] = int.Parse(Console.ReadLine());
            }
        }

        return energyGrid;
    }

    public static void DisplayGrid(int[,] grid)
    {
        int n = grid.GetLength(0);
        Console.WriteLine("\nGirilen Izgara:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write(grid[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }

    public static int FindMinimumEnergyPath(int[,] energyGrid)
    {
        int n = energyGrid.GetLength(0);
        int[,] dp = new int[n, n];

        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                dp[i, j] = int.MaxValue;

        dp[0, 0] = energyGrid[0, 0];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == 0 && j == 0) continue;

                int fromTop = (i > 0) ? dp[i - 1, j] : int.MaxValue;
                int fromLeft = (j > 0) ? dp[i, j - 1] : int.MaxValue;
                int fromDiagonal = (i > 0 && j > 0) ? dp[i - 1, j - 1] : int.MaxValue;

                int minPrevious = Math.Min(Math.Min(fromTop, fromLeft), fromDiagonal);

                if (minPrevious != int.MaxValue)
                    dp[i, j] = minPrevious + energyGrid[i, j];
            }
        }

        return dp[n - 1, n - 1];
    }

    public static void PrintPath(int[,] energyGrid)
    {
        int n = energyGrid.GetLength(0);
        int[,] dp = new int[n, n];
        string[,] path = new string[n, n];

        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
            {
                dp[i, j] = int.MaxValue;
                path[i, j] = "";
            }

        dp[0, 0] = energyGrid[0, 0];
        path[0, 0] = "(0,0)";

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == 0 && j == 0) continue;

                int fromTop = (i > 0) ? dp[i - 1, j] : int.MaxValue;
                int fromLeft = (j > 0) ? dp[i, j - 1] : int.MaxValue;
                int fromDiagonal = (i > 0 && j > 0) ? dp[i - 1, j - 1] : int.MaxValue;

                if (fromTop <= fromLeft && fromTop <= fromDiagonal && fromTop != int.MaxValue)
                {
                    dp[i, j] = fromTop + energyGrid[i, j];
                    path[i, j] = path[i - 1, j] + " -> " + $"({i},{j})";
                }
                else if (fromLeft <= fromTop && fromLeft <= fromDiagonal && fromLeft != int.MaxValue)
                {
                    dp[i, j] = fromLeft + energyGrid[i, j];
                    path[i, j] = path[i, j - 1] + " -> " + $"({i},{j})";
                }
                else if (fromDiagonal != int.MaxValue)
                {
                    dp[i, j] = fromDiagonal + energyGrid[i, j];
                    path[i, j] = path[i - 1, j - 1] + " -> " + $"({i},{j})";
                }
            }
        }

        Console.WriteLine($"\nMinimum enerji: {dp[n - 1, n - 1]}");
        Console.WriteLine($"İzlenen yol: {path[n - 1, n - 1]}");
    }

    public static void Main()
    {
        try
        {
            Console.WriteLine("Asteroit Madenciliği Yol Planlama Sistemi");
            Console.WriteLine("----------------------------------------");

            int[,] energyGrid = GetEnergyGridFromUser();
            DisplayGrid(energyGrid);

            int minEnergy = FindMinimumEnergyPath(energyGrid);
            Console.WriteLine($"\nEn az harcanacak toplam enerji: {minEnergy}");

            Console.WriteLine("\nDetaylı yol bilgisi:");
            PrintPath(energyGrid);
        }
        catch (FormatException)
        {
            Console.WriteLine("\nHata: Lütfen sadece sayı giriniz!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nBir hata oluştu: {ex.Message}");
        }
    }
}
