﻿using System;
using System.Collections.Generic;

class Program
{
    // Asal sayıları kontrol eden fonksiyon
    static bool IsPrime(int number)
    {
        if (number <= 1) return false; // 1 ve daha küçük sayılar asal değildir
        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            if (number % i == 0) return false; // Eğer sayı tam bölünüyorsa asal değildir
        }
        return true; // Sayı asal
    }

    // Ay sayısının basamak toplamının çift olup olmadığını kontrol eden fonksiyon
    static bool IsEvenSumOfDigits(int month)
    {
        int sum = 0;
        while (month > 0)
        {
            sum += month % 10; // Ayın son basamağını alır ve toplar
            month /= 10; // Son basamağı çıkarır
        }
        return sum % 2 == 0; // Toplam çift mi?
    }

    // Yıl sayısının özelliklerini kontrol eden fonksiyon
    static bool IsYearValid(int year)
    {
        int sum = 0;
        int temp = year;

        while (temp > 0)
        {
            sum += temp % 10; // Yılın basamaklarını toplar
            temp /= 10; // Son basamağı çıkarır
        }

        return sum < year / 4; // Yılın dörtte birinden küçük mü?
    }

    // Belirli bir tarih geçerli mi?
    static bool IsValidDate(int day, int month, int year)
    {
        // Ay gün sayıları
        int[] daysInMonth = { 31, 28 + (DateTime.IsLeapYear(year) ? 1 : 0), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        return day > 0 && day <= daysInMonth[month - 1]; // Geçerli gün aralığında mı?
    }

    static void Main()
    {
        List<string> validDates = new List<string>();
        DateTime now = DateTime.Now; // Şu anki tarih
        int startYear = 2000;
        int endYear = 3000;

        // Yıllar arası döngü
        for (int year = startYear; year <= endYear; year++)
        {
            for (int month = 1; month <= 12; month++)
            {
                for (int day = 1; day <= 31; day++)
                {
                    // Geçerli tarih kontrolü
                    if (IsValidDate(day, month, year) &&
                        IsPrime(day) && // Gün asal mı?
                        IsEvenSumOfDigits(month) && // Ay basamak toplamı çift mi?
                        IsYearValid(year)) // Yıl geçerli mi?
                    {
                        DateTime date = new DateTime(year, month, day);
                        // Eğer tarih şu andan büyükse listeye ekle
                        if (date > now)
                        {
                            validDates.Add(date.ToString("dd/MM/yyyy")); // Tarihi formatla ve listeye ekle
                        }
                    }
                }
            }
        }

        // Geçerli tarihleri yazdır
        Console.WriteLine("Geçerli Tarihler:");
        foreach (var validDate in validDates)
        {
            Console.WriteLine(validDate);
        }
    }
}

