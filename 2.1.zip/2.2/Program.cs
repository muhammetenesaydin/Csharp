﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ders1
{
    internal class FileName
    {
        // Programın giriş noktası
        static void Main(string[] args)
        {
            List<int> numbers = new List<int>();
            int input;

            // Pozitif sayılar alınır, 0 girildiğinde döngü sonlanır
            do
            {
                Console.Write("Pozitif bir tam sayı girin (0  girilince yazma biter): ");
                if (int.TryParse(Console.ReadLine(), out input) && input >= 0)
                {
                    if (input > 0)
                    {
                        numbers.Add(input);
                    }
                }
                else
                {
                    Console.WriteLine("Geçerli bir pozitif tam sayı girin.");
                }
            } while (input != 0);

            if (numbers.Count == 0)
            {
                Console.WriteLine("Hiç pozitif sayı girilmedi.");
                return;
            }

            // Ortalama hesaplanır
            double average = numbers.Average();
            Console.WriteLine("Ortalama: " + average);

            // Medyan hesaplanır
            numbers.Sort();
            double median;

            if (numbers.Count % 2 == 0)
            {
                // Çift sayıda eleman varsa ortadaki iki sayının ortalaması alınır
                median = (numbers[numbers.Count / 2 - 1] + numbers[numbers.Count / 2]) / 2.0;
            }
            else
            {
                // Tek sayıda eleman varsa ortadaki sayı medyan olur
                median = numbers[numbers.Count / 2];
            }

            Console.WriteLine("Medyan: " + median);
        }
    }
}
