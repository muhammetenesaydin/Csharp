﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ders1
{
    internal class FileName
    {
        // Programın giriş noktası
        static void Main(string[] args)
        {
            List<int> numbers = new List<int>();
            int input;

            // Pozitif sayılar alınır, 0 girildiğinde döngü sonlanır
            do
            {
                Console.Write("Bir tam sayı girin (0 ile sonlandırın): ");
                if (int.TryParse(Console.ReadLine(), out input) && input >= 0)
                {
                    if (input > 0)
                    {
                        numbers.Add(input);
                    }
                }
                else
                {
                    Console.WriteLine("Geçerli bir tam sayı girin.");
                }
            } while (input != 0);

            if (numbers.Count == 0)
            {
                Console.WriteLine("Hiç sayı girilmedi.");
                return;
            }

            // Diziyi sıralayın
            numbers.Sort();
            Console.WriteLine("Sıralanmış dizi: " + string.Join(", ", numbers));

            // Ardışık grupları bulma işlemi
            List<string> ranges = new List<string>();
            int start = numbers[0];
            int end = numbers[0];

            for (int i = 1; i < numbers.Count; i++)
            {
                if (numbers[i] == end + 1)
                {
                    // Ardışıklık devam ediyorsa, grubu genişlet
                    end = numbers[i];
                }
                else
                {
                    // Yeni bir ardışık grup başlıyor
                    if (start == end)
                    {
                        ranges.Add(start.ToString());
                    }
                    else
                    {
                        ranges.Add($"{start}-{end}");
                    }

                    // Yeni başlangıç ve bitiş değerlerini güncelle
                    start = numbers[i];
                    end = numbers[i];
                }
            }

            // Son grubu ekle
            if (start == end)
            {
                ranges.Add(start.ToString());
            }
            else
            {
                ranges.Add($"{start}-{end}");
            }

            // Grupları ekrana yazdır
            Console.WriteLine("Ardışık gruplar: " + string.Join(", ", ranges));
        }
    }
}

