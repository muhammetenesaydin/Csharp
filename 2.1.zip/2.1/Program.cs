﻿using System;
using System.Linq;

class Program
{
    static int BinarySearch(int[] arr, int target)
    {
        int low = 0;
        int high = arr.Length - 1;

        while (low <= high)
        {
            int mid = (low + high) / 2;

            if (arr[mid] == target)
                return mid; // Sayı bulundu, indeksi döndür

            if (arr[mid] < target)
                low = mid + 1;
            else
                high = mid - 1;
        }

        return -1; // Sayı bulunamadı
    }

    static void Main()
    {
        // Kullanıcıdan bir dizi tam sayı alın
        Console.Write("Bir dizi tam sayı girin (virgülle ayırın): ");
        int[] numbers;
        try
        {
            numbers = Console.ReadLine().Split(',').Select(int.Parse).ToArray();
        }
        catch
        {
            Console.WriteLine("Lütfen yalnızca tam sayılar girin.");
            return;
        }

        // Diziyi sıralayın
        Array.Sort(numbers);
        Console.WriteLine("Sıralanmış dizi: " + string.Join(", ", numbers));

        // Kullanıcıdan bir sayı alın
        Console.Write("Aramak istediğiniz sayıyı girin: ");
        int target;
        try
        {
            target = int.Parse(Console.ReadLine());
        }
        catch
        {
            Console.WriteLine("Lütfen geçerli bir tam sayı girin.");
            return;
        }

        // İkili arama algoritmasıyla sayının olup olmadığını kontrol edin
        int index = BinarySearch(numbers, target);

        // Sonucu ekrana yazdırın
        if (index != -1)
        {
            Console.WriteLine($"{target} sayısı dizide bulundu. İndeks: {index}");
        }
        else
        {
            Console.WriteLine($"{target} sayısı dizide bulunamadı.");
        }
    }
}
