﻿using System;
using System.Collections.Generic;

class Program
{
    // Operatörlerin önceliklerini tanımlayın
    static int GetPrecedence(char op)
    {
        return op switch
        {
            '+' or '-' => 1,
            '*' or '/' => 2,
            '^' => 3,
            _ => 0,
        };
    }

    // İki sayıyı ve bir operatörü alıp işlemi gerçekleştirir
    static double ApplyOperation(double a, double b, char op)
    {
        return op switch
        {
            '+' => a + b,
            '-' => a - b,
            '*' => a * b,
            '/' => a / b,
            '^' => Math.Pow(a, b),
            _ => 0,
        };
    }

    // İfadeyi postfix'e dönüştürmek için Shunting-yard algoritması
    static List<string> InfixToPostfix(string expression)
    {
        Stack<char> operators = new Stack<char>();
        List<string> postfix = new List<string>();
        int i = 0;

        while (i < expression.Length)
        {
            char c = expression[i];

            // Sayıları alır ve postfix listesine ekler
            if (char.IsDigit(c) || c == '.')
            {
                string number = "";
                while (i < expression.Length && (char.IsDigit(expression[i]) || expression[i] == '.'))
                {
                    number += expression[i];
                    i++;
                }
                postfix.Add(number);
                continue;
            }
            // Parantezleri yönetir
            else if (c == '(')
            {
                operators.Push(c);
            }
            else if (c == ')')
            {
                while (operators.Peek() != '(')
                {
                    postfix.Add(operators.Pop().ToString());
                }
                operators.Pop();
            }
            // Operatörleri yönetir
            else if ("+-*/^".Contains(c))
            {
                while (operators.Count > 0 && GetPrecedence(operators.Peek()) >= GetPrecedence(c))
                {
                    postfix.Add(operators.Pop().ToString());
                }
                operators.Push(c);
            }

            i++;
        }

        while (operators.Count > 0)
        {
            postfix.Add(operators.Pop().ToString());
        }

        return postfix;
    }

    // Postfix ifadesini çözer
    static double EvaluatePostfix(List<string> postfix)
    {
        Stack<double> stack = new Stack<double>();

        foreach (var token in postfix)
        {
            if (double.TryParse(token, out double number))
            {
                stack.Push(number);
            }
            else if (token.Length == 1 && "+-*/^".Contains(token))
            {
                double b = stack.Pop();
                double a = stack.Pop();
                double result = ApplyOperation(a, b, token[0]);
                stack.Push(result);
                Console.WriteLine($"{a} {token} {b} = {result}");
            }
        }

        return stack.Pop();
    }

    static void Main()
    {
        Console.WriteLine("Bir matematiksel ifade girin: ");
        string expression = Console.ReadLine();

        List<string> postfix = InfixToPostfix(expression);

        Console.WriteLine("Postfix ifadesi: " + string.Join(" ", postfix));

        Console.WriteLine("\nÇözüm Süreci:");
        double result = EvaluatePostfix(postfix);

        Console.WriteLine($"\nSonuç: {result}");
    }
}
