﻿using System;
using System.Collections.Generic;
using System.Text;

public class MessageDecryption
{
    // Fibonacci sayılarını hesaplayan ve önbelleğe alan sınıf
    private class FibonacciCache
    {
        private List<long> fibNumbers = new List<long> { 1, 1 };

        public long GetFibonacci(int n)
        {
            // İstenen Fibonacci sayısı zaten hesaplanmışsa, onu döndür
            while (fibNumbers.Count <= n)
            {
                fibNumbers.Add(fibNumbers[fibNumbers.Count - 1] + fibNumbers[fibNumbers.Count - 2]);
            }
            return fibNumbers[n];
        }
    }

    // Bir sayının asal olup olmadığını kontrol eden metod
    private static bool IsPrime(int number)
    {
        if (number <= 1) return false;
        if (number == 2) return true;
        if (number % 2 == 0) return false;

        var boundary = (int)Math.Floor(Math.Sqrt(number));
        for (int i = 3; i <= boundary; i += 2)
        {
            if (number % i == 0) return false;
        }
        return true;
    }

    // Modüler aritmetik için kullanılacak tersini bulan fonksiyon
    private static long ModularMultiplicativeInverse(long a, long m)
    {
        long m0 = m;
        long y = 0, x = 1;

        if (m == 1)
            return 0;

        while (a > 1)
        {
            long q = a / m;
            long t = m;

            m = a % m;
            a = t;
            t = y;

            y = x - q * y;
            x = t;
        }

        if (x < 0)
            x += m0;

        return x;
    }

    // Şifrelenmiş mesajı çözen ana metod
    public static string DecryptMessage(string encryptedMessage)
    {
        var fibCache = new FibonacciCache();
        var decrypted = new StringBuilder();

        for (int position = 0; position < encryptedMessage.Length; position++)
        {
            int currentChar = encryptedMessage[position];
            int positionInSequence = position + 1;
            long fibNumber = fibCache.GetFibonacci(positionInSequence - 1);

            // Modüler çözümlemeyi tersine çevir
            int modulus = IsPrime(positionInSequence) ? 100 : 256;

            // Modüler aritmetik işlemleri
            long originalAscii = currentChar;
            long fibInverse = ModularMultiplicativeInverse(fibNumber % modulus, modulus);
            originalAscii = (originalAscii * fibInverse) % modulus;

            // ASCII karakterine dönüştür
            decrypted.Append((char)originalAscii);
        }

        return decrypted.ToString();
    }

    // Mesajı şifreleyen metod (test için)
    public static string EncryptMessage(string message)
    {
        var fibCache = new FibonacciCache();
        var encrypted = new StringBuilder();

        for (int position = 0; position < message.Length; position++)
        {
            int currentChar = message[position];
            int positionInSequence = position + 1;
            long fibNumber = fibCache.GetFibonacci(positionInSequence - 1);

            // ASCII değerini Fibonacci sayısıyla çarp
            long newValue = currentChar * fibNumber;

            // Modüler çözümleme
            int modulus = IsPrime(positionInSequence) ? 100 : 256;
            newValue = newValue % modulus;

            // Yeni karakteri ekle
            encrypted.Append((char)newValue);
        }

        return encrypted.ToString();
    }

    public static void Main()
    {
        try
        {
            Console.WriteLine("Mesaj Şifreleme ve Çözme Sistemi");
            Console.WriteLine("--------------------------------");

            while (true)
            {
                Console.WriteLine("\n1 - Mesaj Şifrele");
                Console.WriteLine("2 - Şifrelenmiş Mesajı Çöz");
                Console.WriteLine("3 - Çıkış");
                Console.Write("\nSeçiminiz (1-3): ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("\nŞifrelenecek mesajı girin: ");
                        string originalMessage = Console.ReadLine();
                        string encrypted = EncryptMessage(originalMessage);
                        Console.WriteLine($"Şifrelenmiş mesaj: {encrypted}");
                        break;

                    case "2":
                        Console.Write("\nÇözülecek şifreli mesajı girin: ");
                        string encryptedMessage = Console.ReadLine();
                        string decrypted = DecryptMessage(encryptedMessage);
                        Console.WriteLine($"Çözülmüş mesaj: {decrypted}");
                        break;

                    case "3":
                        Console.WriteLine("\nProgramdan çıkılıyor...");
                        return;

                    default:
                        Console.WriteLine("\nGeçersiz seçim! Lütfen tekrar deneyin.");
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nBir hata oluştu: {ex.Message}");
        }
    }
}