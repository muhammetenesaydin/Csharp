﻿using System;
using System.Collections.Generic;

class Program
{
    // Asal sayıları kontrol eden fonksiyon
    static bool IsPrime(int number)
    {
        if (number <= 1) return false; // 1 ve daha küçük sayılar asal değildir
        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            if (number % i == 0) return false; // Eğer sayı tam bölünüyorsa asal değildir
        }
        return true; // Sayı asal
    }

    // Bir hücrenin geçerli olup olmadığını kontrol eden fonksiyon
    static bool IsValidCell(int x, int y)
    {
        // Her iki koordinat da asal mı?
        if (!IsPrime(x) || !IsPrime(y)) return false;

        // x ve y toplamı, çarpımına bölünebilir mi?
        int sum = x + y;
        int product = x * y;
        return product != 0 && sum % product == 0; // Çarpım sıfır olmamalı
    }

    // Labirent çözme fonksiyonu
    static bool FindPath(int x, int y, int M, int N, List<string> path, bool[,] visited)
    {
        // Şehir koordinatı
        if (x == M - 1 && y == N - 1)
        {
            path.Add($"({x}, {y})"); // Şehre ulaşınca yol adımını ekle
            return true;
        }

        // Geçerli hücre kontrolü
        if (x < 0 || x >= M || y < 0 || y >= N || !IsValidCell(x, y) || visited[x, y])
            return false;

        // Hücreyi ziyaret edildi olarak işaretle
        visited[x, y] = true;
        path.Add($"({x}, {y})"); // Mevcut hücreyi yol adımlarına ekle

        // Komşu hücrelere git
        // Aşağı
        if (FindPath(x + 1, y, M, N, path, visited) ||
            // Sağa
            FindPath(x, y + 1, M, N, path, visited) ||
            // Yukarı
            FindPath(x - 1, y, M, N, path, visited) ||
            // Sola
            FindPath(x, y - 1, M, N, path, visited))
        {
            return true;
        }

        // Eğer komşulardan hiçbiri geçerli değilse, bu hücreden çık
        path.RemoveAt(path.Count - 1); // Son adımı kaldır
        visited[x, y] = false; // Ziyareti geri al
        return false;
    }

    static void Main()
    {
        int M = 10; // Labirentin satır sayısı
        int N = 10; // Labirentin sütun sayısı
        bool[,] visited = new bool[M, N]; // Ziyaret edilen hücreleri takip et
        List<string> path = new List<string>(); // Geçerli yol adımlarını saklamak için liste

        // Labirenti çöz
        if (FindPath(0, 0, M, N, path, visited))
        {
            Console.WriteLine("Şehre ulaşan yol:");
            foreach (var step in path)
            {
                Console.WriteLine(step);
            }
        }
        else
        {
            Console.WriteLine("Şehir kayboldu!");
        }

        // Programın bitmesini engellemek için bir tuşa basmayı bekleyin
        Console.WriteLine("Çıkmak için bir tuşa basın...");
        Console.ReadKey();
    }
}
