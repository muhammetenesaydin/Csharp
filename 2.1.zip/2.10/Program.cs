﻿using System;
using System.Collections.Generic;
using System.Linq;

public class GizemliKapi
{
    private readonly char[] operatorler = { '+', '-', '*', '/' };
    private List<string> cozumler;

    public GizemliKapi()
    {
        cozumler = new List<string>();
    }

    private double IslemiHesapla(string islem)
    {
        try
        {
            // İşlemi parçalara ayır
            string[] parcalar = islem.Split(' ');
            double sonuc = Convert.ToDouble(parcalar[0]);

            // Her operatör ve sayı çifti için işlem yap
            for (int i = 1; i < parcalar.Length; i += 2)
            {
                char op = parcalar[i][0];
                double sayi = Convert.ToDouble(parcalar[i + 1]);

                switch (op)
                {
                    case '+': sonuc += sayi; break;
                    case '-': sonuc -= sayi; break;
                    case '*': sonuc *= sayi; break;
                    case '/':
                        if (sayi == 0) return -1;
                        sonuc /= sayi;
                        break;
                }
            }
            return sonuc;
        }
        catch
        {
            return -1;
        }
    }

    private bool KurallariKontrolEt(string islem)
    {
        // Kural 1: Sonuç sıfırdan büyük olmalı
        double sonuc = IslemiHesapla(islem);
        if (sonuc <= 0)
            return false;

        // Kural 2: İki operatör ardışık olamaz
        string[] parcalar = islem.Split(' ');
        for (int i = 1; i < parcalar.Length - 1; i += 2)
        {
            if (operatorler.Contains(parcalar[i][0]) && operatorler.Contains(parcalar[i + 1][0]))
                return false;
        }

        return true;
    }

    public void KombinasyonlariUret(int[] sayilar)
    {
        if (sayilar == null || sayilar.Length < 2)
            return;

        string baslangic = sayilar[0].ToString();
        KombinasyonlariUretRecursive(sayilar, baslangic, 1);
    }

    private void KombinasyonlariUretRecursive(int[] sayilar, string mevcutIslem, int index)
    {
        if (index == sayilar.Length)
        {
            if (KurallariKontrolEt(mevcutIslem))
                cozumler.Add(mevcutIslem);
            return;
        }

        foreach (char op in operatorler)
        {
            string yeniIslem = $"{mevcutIslem} {op} {sayilar[index]}";
            KombinasyonlariUretRecursive(sayilar, yeniIslem, index + 1);
        }
    }

    public void CozumleriGoster()
    {
        if (cozumler.Count == 0)
        {
            Console.WriteLine("Geçerli çözüm bulunamadı!");
            return;
        }

        Console.WriteLine("\nBulunan çözümler:");
        foreach (string cozum in cozumler)
        {
            double sonuc = IslemiHesapla(cozum);
            Console.WriteLine($"{cozum} = {sonuc}");
        }
    }

    public static void Main(string[] args)
    {
        GizemliKapi kapi = new GizemliKapi();
        int[] testSayilar = { 5, 3, 2 }; // Örnek sayı dizisi

        Console.WriteLine("Gizemli Kapı bulmacasını çözmeye çalışıyorum...");
        Console.WriteLine($"Kullanılan sayılar: {string.Join(", ", testSayilar)}");

        kapi.KombinasyonlariUret(testSayilar);
        kapi.CozumleriGoster();
    }
}