﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    // Polinom sınıfı
    public class Polynomial
    {
        public Dictionary<int, double> Terms { get; private set; } // Derecelere göre terimler

        public Polynomial(string polynomial)
        {
            Terms = new Dictionary<int, double>();
            ParsePolynomial(polynomial);
        }

        // Polinom metnini çözümleme
        private void ParsePolynomial(string polynomial)
        {
            // Polinom terimlerini ayırmak için düzenli ifade
            string pattern = @"([+-]?\s*\d*\.?\d*)x?\^?(\d*)";
            MatchCollection matches = Regex.Matches(polynomial.Replace(" ", ""), pattern);

            foreach (Match match in matches)
            {
                double coefficient = string.IsNullOrEmpty(match.Groups[1].Value) || match.Groups[1].Value == "+" ? 1 :
                                     match.Groups[1].Value == "-" ? -1 : double.Parse(match.Groups[1].Value);

                int degree = match.Groups[2].Success ? int.Parse(match.Groups[2].Value) : (match.Groups[0].Value.Contains("x") ? 1 : 0);

                if (Terms.ContainsKey(degree))
                {
                    Terms[degree] += coefficient; // Aynı dereceden terimlerin katsayılarını toplar
                }
                else
                {
                    Terms[degree] = coefficient; // Yeni terim ekler
                }
            }
        }

        // İki polinomu toplama
        public Polynomial Add(Polynomial other)
        {
            Polynomial result = new Polynomial("0");
            foreach (var term in Terms)
            {
                result.Terms[term.Key] = term.Value; // Bu polinomun terimlerini ekler
            }
            foreach (var term in other.Terms)
            {
                if (result.Terms.ContainsKey(term.Key))
                {
                    result.Terms[term.Key] += term.Value; // Diğer polinomun terimlerini toplar
                }
                else
                {
                    result.Terms[term.Key] = term.Value; // Yeni terim ekler
                }
            }
            return result;
        }

        // İki polinomu çıkarma
        public Polynomial Subtract(Polynomial other)
        {
            Polynomial result = new Polynomial("0");
            foreach (var term in Terms)
            {
                result.Terms[term.Key] = term.Value; // Bu polinomun terimlerini ekler
            }
            foreach (var term in other.Terms)
            {
                if (result.Terms.ContainsKey(term.Key))
                {
                    result.Terms[term.Key] -= term.Value; // Diğer polinomun terimlerini çıkarır
                }
                else
                {
                    result.Terms[term.Key] = -term.Value; // Yeni terim ekler (negatif katsayı)
                }
            }
            return result;
        }

        // Polinomun metin temsili
        public override string ToString()
        {
            List<string> terms = new List<string>();
            foreach (var term in Terms)
            {
                if (term.Value == 0) continue; // Katsayısı sıfır olan terimleri atla
                string sign = term.Value > 0 && terms.Count > 0 ? "+" : ""; // Pozitif terimler için "+" işareti ekler
                if (term.Key == 0)
                {
                    terms.Add($"{sign}{term.Value}"); // Sabit terim
                }
                else if (term.Key == 1)
                {
                    terms.Add($"{sign}{term.Value}x"); // x terimi
                }
                else
                {
                    terms.Add($"{sign}{term.Value}x^{term.Key}"); // Diğer terimler
                }
            }
            return string.Join(" ", terms);
        }
    }

    static void Main()
    {
        while (true)
        {
            // Kullanıcıdan iki polinom alır
            Console.WriteLine("Birinci polinomu girin (veya çıkmak için 'exit' yazın): ");
            string input1 = Console.ReadLine();
            if (input1.ToLower() == "exit") break;

            Console.WriteLine("İkinci polinomu girin: ");
            string input2 = Console.ReadLine();
            if (input2.ToLower() == "exit") break;

            // Polinomları oluşturur
            Polynomial poly1 = new Polynomial(input1);
            Polynomial poly2 = new Polynomial(input2);

            // Polinomları toplar ve çıkarır
            Polynomial sum = poly1.Add(poly2);
            Polynomial difference = poly1.Subtract(poly2);

            // Sonuçları ekrana yazdırır
            Console.WriteLine($"Toplam: {sum}");
            Console.WriteLine($"Fark: {difference}");
            Console.WriteLine();
        }
    }
}
