﻿using System;
using System.Collections.Generic;

class Kisi
{
    // Özellikler
    public string Ad { get; set; }
    public string Soyad { get; set; }
    public string TelefonNumarasi { get; set; }

    // Yapıcı Metot
    public Kisi(string ad, string soyad, string telefonNumarasi)
    {
        Ad = ad;
        Soyad = soyad;
        TelefonNumarasi = telefonNumarasi;
    }

    // KisiBilgisi metodu
    public string KisiBilgisi()
    {
        return $"{Ad} {Soyad} - {TelefonNumarasi}";
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Kisi> adresDefteri = new List<Kisi>(); // Adres defteri için bir liste oluştur
        bool devamEt = true;

        while (devamEt)
        {
            Console.WriteLine("\nAdres Defteri Menü:");
            Console.WriteLine("1 - Yeni Kişi Ekle");
            Console.WriteLine("2 - Kişileri Listele");
            Console.WriteLine("3 - Çıkış");

            Console.Write("Bir seçim yapın: ");
            int secim;
            if (!int.TryParse(Console.ReadLine(), out secim))
            {
                Console.WriteLine("Geçersiz giriş. Lütfen bir sayı girin.");
                continue;
            }

            switch (secim)
            {
                case 1:
                    // Yeni kişi ekle
                    Console.Write("Ad: ");
                    string ad = Console.ReadLine();

                    Console.Write("Soyad: ");
                    string soyad = Console.ReadLine();

                    Console.Write("Telefon Numarası: ");
                    string telefonNumarasi = Console.ReadLine();

                    Kisi yeniKisi = new Kisi(ad, soyad, telefonNumarasi);
                    adresDefteri.Add(yeniKisi);
                    Console.WriteLine("Kişi başarıyla eklendi!");
                    break;

                case 2:
                    // Kişileri listele
                    if (adresDefteri.Count == 0)
                    {
                        Console.WriteLine("Adres defterinde kayıtlı kişi yok.");
                    }
                    else
                    {
                        Console.WriteLine("\nAdres Defterindeki Kişiler:");
                        foreach (var kisi in adresDefteri)
                        {
                            Console.WriteLine(kisi.KisiBilgisi());
                        }
                    }
                    break;

                case 3:
                    // Çıkış
                    devamEt = false;
                    Console.WriteLine("Programdan çıkılıyor...");
                    break;

                default:
                    Console.WriteLine("Geçersiz seçim. Lütfen 1-3 arasında bir değer girin.");
                    break;
            }
        }
    }
}
