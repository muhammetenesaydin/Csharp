﻿using System;
using System.Collections.Generic;

class Kitap
{
    // Özellikler
    public string Ad { get; set; }
    public string Yazar { get; set; }
    public string ISBN { get; set; }

    // Yapıcı Metot
    public Kitap(string ad, string yazar, string isbn)
    {
        Ad = ad;
        Yazar = yazar;
        ISBN = isbn;
    }
}

class Kutuphane
{
    // Kitaplar listesi
    public List<Kitap> Kitaplar { get; private set; }

    // Yapıcı Metot
    public Kutuphane()
    {
        Kitaplar = new List<Kitap>(); // Kitap listesi boş olarak başlatılır
    }

    // Kitap ekleme metodu
    public void KitapEkle(Kitap yeniKitap)
    {
        this.Kitaplar.Add(yeniKitap); // Kitap, kütüphaneye ekleniyor
        Console.WriteLine("Kitap kütüphaneye eklendi.");
    }

    // Kitapları listeleme metodu
    public void KitaplariListele()
    {
        if (Kitaplar.Count == 0)
        {
            Console.WriteLine("Kütüphanede kayıtlı kitap bulunmamaktadır.");
        }
        else
        {
            Console.WriteLine("\nKütüphanedeki Kitaplar:");
            foreach (var kitap in Kitaplar)
            {
                Console.WriteLine($"Ad: {kitap.Ad}, Yazar: {kitap.Yazar}, ISBN: {kitap.ISBN}");
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Kutuphane kutuphane = new Kutuphane(); // Yeni bir kütüphane nesnesi oluşturuluyor
        bool devamEt = true;

        while (devamEt)
        {
            Console.WriteLine("\nKütüphane Menü:");
            Console.WriteLine("1 - Kitap Ekle");
            Console.WriteLine("2 - Kitapları Listele");
            Console.WriteLine("3 - Çıkış");

            Console.Write("Bir seçim yapın: ");
            int secim;
            if (!int.TryParse(Console.ReadLine(), out secim))
            {
                Console.WriteLine("Geçersiz giriş. Lütfen bir sayı girin.");
                continue;
            }

            switch (secim)
            {
                case 1:
                    // Yeni kitap ekle
                    Console.Write("Kitap adı: ");
                    string ad = Console.ReadLine();

                    Console.Write("Yazar adı: ");
                    string yazar = Console.ReadLine();

                    Console.Write("ISBN numarası: ");
                    string isbn = Console.ReadLine();

                    Kitap yeniKitap = new Kitap(ad, yazar, isbn);
                    kutuphane.KitapEkle(yeniKitap);
                    break;

                case 2:
                    // Kitapları listele
                    kutuphane.KitaplariListele();
                    break;

                case 3:
                    // Çıkış
                    devamEt = false;
                    Console.WriteLine("Programdan çıkılıyor...");
                    break;

                default:
                    Console.WriteLine("Geçersiz seçim. Lütfen 1-3 arasında bir değer girin.");
                    break;
            }
        }
    }
}
