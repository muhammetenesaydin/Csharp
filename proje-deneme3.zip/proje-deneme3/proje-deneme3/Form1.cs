﻿using System;
using System.Data;
using System.Threading.Tasks;
using Npgsql;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace proje_deneme3
{
    public partial class Form1 : XtraForm
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly ILogger<Form1> _logger;

        public Form1(ICustomerRepository customerRepository, ILogger<Form1> logger)
        {
            InitializeComponent();
            _customerRepository = customerRepository;
            _logger = logger;
            LoadDataAsync().ConfigureAwait(false); // Asenkron veri yükleme
        }

        // Verileri asenkron olarak yükle
        private async Task LoadDataAsync()
        {
            await LoadLastTenCustomersAsync();
            await LoadCurrentCustomersAsync();
        }

        // Son 10 müşteriyi asenkron olarak yükle
        private async Task LoadLastTenCustomersAsync()
        {
            try
            {
                var customers = await _customerRepository.GetLastTenCustomersAsync();
                gridLastTenCustomers.DataSource = customers;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Müşteri verileri yüklenirken hata oluştu.");
                ShowError("Müşteri verileri yüklenirken hata: " + ex.Message);
            }
        }

        // Şu anki müşterileri asenkron olarak yükle
        private async Task LoadCurrentCustomersAsync()
        {
            try
            {
                var customers = await _customerRepository.GetCurrentCustomersAsync();
                gridCurrentCustomers.DataSource = customers;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Şu anki işlemler yüklenirken hata oluştu.");
                ShowError("Şu anki işlemler yüklenirken hata: " + ex.Message);
            }
        }

        // Müşteri arama işlemi
        private async void btnSearch_Click(object sender, EventArgs e)
        {
            string customerName = txtCustomerName.Text;
            try
            {
                var customer = await _customerRepository.GetCustomerByNameAsync(customerName);
                if (customer != null)
                {
                    lblSearchResult.Text = $"Ad: {customer.Name}, Kalite: {customer.Quality}, Miktar: {customer.Amount} ton";
                }
                else
                {
                    lblSearchResult.Text = "Müşteri bulunamadı.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Müşteri arama sırasında hata oluştu.");
                ShowError("Müşteri arama sırasında hata: " + ex.Message);
            }
        }

        // Yeni müşteri ekleme işlemi
        private async void btnAddCustomer_Click(object sender, EventArgs e)
        {
            string name = txtNewCustomerName.Text;
            double amount = Convert.ToDouble(txtNewCustomerAmount.Text);
            string quality = txtNewCustomerQuality.Text;

            try
            {
                await _customerRepository.AddCustomerAsync(name, amount, quality);
                MessageBox.Show("Müşteri başarıyla eklendi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                await LoadCurrentCustomersAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Müşteri ekleme sırasında hata oluştu.");
                ShowError("Müşteri ekleme sırasında hata: " + ex.Message);
            }
        }

        // Hata mesajlarını göstermek için yardımcı metod
        private void ShowError(string message)
        {
            MessageBox.Show(message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

    // Müşteri repository interface'i
    public interface ICustomerRepository
    {
        Task<DataTable> GetLastTenCustomersAsync();
        Task<DataTable> GetCurrentCustomersAsync();
        Task<Customer> GetCustomerByNameAsync(string name);
        Task AddCustomerAsync(string name, double amount, string quality);
    }

    // Müşteri repository implementasyonu
    public class CustomerRepository : ICustomerRepository
    {
        private readonly string _connectionString;
        private readonly ILogger<CustomerRepository> _logger;

        public CustomerRepository(string connectionString, ILogger<CustomerRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public async Task<DataTable> GetLastTenCustomersAsync()
        {
            return await ExecuteQueryAsync("SELECT * FROM customers ORDER BY id DESC LIMIT 10;");
        }

        public async Task<DataTable> GetCurrentCustomersAsync()
        {
            return await ExecuteQueryAsync("SELECT * FROM customers WHERE status = 'InProgress';");
        }

        public async Task<Customer> GetCustomerByNameAsync(string name)
        {
            var table = await ExecuteQueryAsync(
                "SELECT name, quality, amount FROM customers WHERE name = @name;",
                new NpgsqlParameter("@name", name));

            if (table.Rows.Count > 0)
            {
                var row = table.Rows[0];
                return new Customer
                {
                    Name = row["name"].ToString(),
                    Quality = row["quality"].ToString(),
                    Amount = Convert.ToDouble(row["amount"])
                };
            }
            return null;
        }

        public async Task AddCustomerAsync(string name, double amount, string quality)
        {
            await ExecuteNonQueryAsync(
                "INSERT INTO customers (name, amount, quality, status) VALUES (@name, @amount, @quality, 'InProgress');",
                new NpgsqlParameter("@name", name),
                new NpgsqlParameter("@amount", amount),
                new NpgsqlParameter("@quality", quality));
        }

        private async Task<DataTable> ExecuteQueryAsync(string query, params NpgsqlParameter[] parameters)
        {
            using (var connection = new NpgsqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddRange(parameters);
                    using (var adapter = new NpgsqlDataAdapter(command))
                    {
                        var table = new DataTable();
                        await Task.Run(() => adapter.Fill(table));
                        return table;
                    }
                }
            }
        }

        private async Task ExecuteNonQueryAsync(string query, params NpgsqlParameter[] parameters)
        {
            using (var connection = new NpgsqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var command = new NpgsqlCommand(query, connection))
                {
                    command.Parameters.AddRange(parameters);
                    await command.ExecuteNonQueryAsync();
                }
            }
        }
    }

    // Müşteri modeli
    public class Customer
    {
        public string Name { get; set; }
        public string Quality { get; set; }
        public double Amount { get; set; }
    }

    // Program.cs (Dependency Injection ayarları)
    public static class Program
    {
        [STAThread]
        public static void Main()
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            using (var serviceProvider = services.BuildServiceProvider())
            {
                var form = serviceProvider.GetRequiredService<Form1>();
                Application.Run(form);
            }
        }

        private static void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(configure => configure.AddConsole())
                    .AddSingleton<ICustomerRepository, CustomerRepository>()
                    .AddTransient<Form1>();
        }
    }
}