﻿namespace proje_deneme3
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblWeather = new System.Windows.Forms.Label();
            this.lblPrediction = new System.Windows.Forms.Label();
            this.gridCurrentCustomers = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridLastTenCustomers = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.txtNewCustomerName = new System.Windows.Forms.TextBox();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.lblLastTenCustomers = new System.Windows.Forms.Label();
            this.lblCurrentCustomers = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridCurrentCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLastTenCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWeather
            // 
            this.lblWeather.AutoSize = true;
            this.lblWeather.BackColor = System.Drawing.SystemColors.HighlightText;
            this.lblWeather.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblWeather.Location = new System.Drawing.Point(12, 62);
            this.lblWeather.Name = "lblWeather";
            this.lblWeather.Size = new System.Drawing.Size(185, 29);
            this.lblWeather.TabIndex = 0;
            this.lblWeather.Text = "Hava Durumu:";
            // 
            // lblPrediction
            // 
            this.lblPrediction.AutoSize = true;
            this.lblPrediction.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPrediction.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPrediction.Location = new System.Drawing.Point(253, 62);
            this.lblPrediction.Name = "lblPrediction";
            this.lblPrediction.Size = new System.Drawing.Size(54, 21);
            this.lblPrediction.TabIndex = 1;
            this.lblPrediction.Text = "label2";
            // 
            // gridCurrentCustomers
            // 
            this.gridCurrentCustomers.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridCurrentCustomers.Location = new System.Drawing.Point(815, 62);
            this.gridCurrentCustomers.MainView = this.gridView1;
            this.gridCurrentCustomers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridCurrentCustomers.Name = "gridCurrentCustomers";
            this.gridCurrentCustomers.Size = new System.Drawing.Size(390, 322);
            this.gridCurrentCustomers.TabIndex = 2;
            this.gridCurrentCustomers.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.DetailHeight = 431;
            this.gridView1.GridControl = this.gridCurrentCustomers;
            this.gridView1.Name = "gridView1";
            // 
            // gridLastTenCustomers
            // 
            this.gridLastTenCustomers.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridLastTenCustomers.Location = new System.Drawing.Point(417, 62);
            this.gridLastTenCustomers.MainView = this.gridView2;
            this.gridLastTenCustomers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridLastTenCustomers.Name = "gridLastTenCustomers";
            this.gridLastTenCustomers.Size = new System.Drawing.Size(370, 322);
            this.gridLastTenCustomers.TabIndex = 3;
            this.gridLastTenCustomers.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.DetailHeight = 431;
            this.gridView2.GridControl = this.gridLastTenCustomers;
            this.gridView2.Name = "gridView2";
            // 
            // txtNewCustomerName
            // 
            this.txtNewCustomerName.BackColor = System.Drawing.Color.White;
            this.txtNewCustomerName.Cursor = System.Windows.Forms.Cursors.No;
            this.txtNewCustomerName.Location = new System.Drawing.Point(14, 454);
            this.txtNewCustomerName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNewCustomerName.Name = "txtNewCustomerName";
            this.txtNewCustomerName.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtNewCustomerName.Size = new System.Drawing.Size(335, 23);
            this.txtNewCustomerName.TabIndex = 5;
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(402, 452);
            this.btnAddCustomer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(87, 28);
            this.btnAddCustomer.TabIndex = 6;
            this.btnAddCustomer.Text = "button1";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            // 
            // dockManager1
            // 
            this.dockManager1.Form = this;
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl"});
            // 
            // layoutControl1
            // 
            this.layoutControl1.BackColor = System.Drawing.Color.Khaki;
            this.layoutControl1.Location = new System.Drawing.Point(47, 286);
            this.layoutControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(260, 110);
            this.layoutControl1.TabIndex = 7;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(260, 110);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // lblLastTenCustomers
            // 
            this.lblLastTenCustomers.AutoSize = true;
            this.lblLastTenCustomers.BackColor = System.Drawing.Color.Ivory;
            this.lblLastTenCustomers.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLastTenCustomers.Location = new System.Drawing.Point(413, 25);
            this.lblLastTenCustomers.Name = "lblLastTenCustomers";
            this.lblLastTenCustomers.Size = new System.Drawing.Size(162, 24);
            this.lblLastTenCustomers.TabIndex = 8;
            this.lblLastTenCustomers.Text = "Son 10 Müşteri";
            // 
            // lblCurrentCustomers
            // 
            this.lblCurrentCustomers.AutoSize = true;
            this.lblCurrentCustomers.BackColor = System.Drawing.Color.Ivory;
            this.lblCurrentCustomers.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCurrentCustomers.Location = new System.Drawing.Point(826, 25);
            this.lblCurrentCustomers.Name = "lblCurrentCustomers";
            this.lblCurrentCustomers.Size = new System.Drawing.Size(211, 24);
            this.lblCurrentCustomers.TabIndex = 9;
            this.lblCurrentCustomers.Text = "Kantardaki İşlemler";
            // 
            // Form1
            // 
            this.Appearance.BackColor = System.Drawing.Color.YellowGreen;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1375, 828);
            this.Controls.Add(this.lblCurrentCustomers);
            this.Controls.Add(this.lblLastTenCustomers);
            this.Controls.Add(this.layoutControl1);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.txtNewCustomerName);
            this.Controls.Add(this.gridLastTenCustomers);
            this.Controls.Add(this.gridCurrentCustomers);
            this.Controls.Add(this.lblPrediction);
            this.Controls.Add(this.lblWeather);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridCurrentCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLastTenCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWeather;
        private System.Windows.Forms.Label lblPrediction;
        private DevExpress.XtraGrid.GridControl gridCurrentCustomers;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.GridControl gridLastTenCustomers;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private System.Windows.Forms.TextBox txtNewCustomerName;
        private System.Windows.Forms.Button btnAddCustomer;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private System.Windows.Forms.Label lblCurrentCustomers;
        private System.Windows.Forms.Label lblLastTenCustomers;
    }
}

