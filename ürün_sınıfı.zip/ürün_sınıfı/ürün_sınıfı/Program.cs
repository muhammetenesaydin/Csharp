﻿using System;

class Urun
{
    // Özellikler
    public string Ad { get; set; }
    public decimal Fiyat { get; set; }

    private decimal indirim;
    public decimal Indirim
    {
        get { return indirim; }
        set
        {
            if (value < 0 || value > 50)
            {
                throw new ArgumentOutOfRangeException(nameof(Indirim), "İndirim oranı 0 ile 50 arasında olmalıdır.");
            }
            indirim = value;
        }
    }

    // Yapıcı Metot
    public Urun(string ad, decimal fiyat)
    {
        Ad = ad;
        Fiyat = fiyat;
    }

    // İndirimli fiyatı döndüren metot
    public decimal IndirimliFiyat()
    {
        return Fiyat * (1 - Indirim / 100);
    }
}

// Kullanımusing System;

class Program
{
    static void Main(string[] args)
    {
        try
        {
            // İlk ürün bilgilerini al
            Console.WriteLine("1. Ürün adı girin:");
            string ad1 = Console.ReadLine();

            Console.WriteLine("1. Ürün fiyatını girin (TL):");
            decimal fiyat1 = Convert.ToDecimal(Console.ReadLine());

            Urun urun1 = new Urun(ad1, fiyat1);

            Console.WriteLine("1. Ürün için indirim oranını girin (%):");
            decimal indirim1 = Convert.ToDecimal(Console.ReadLine());
            urun1.Indirim = indirim1; // İndirim oranını ayarla

            // İlk ürün bilgilerini ekrana yazdır
            Console.WriteLine("\n1. Ürün Bilgileri:");
            Console.WriteLine($"Ürün: {urun1.Ad}");
            Console.WriteLine($"Fiyat: {urun1.Fiyat} TL");
            Console.WriteLine($"İndirimli Fiyat: {urun1.IndirimliFiyat()} TL");

            // İkinci ürün bilgilerini al
            Console.WriteLine("\n2. Ürün adı girin:");
            string ad2 = Console.ReadLine();

            Console.WriteLine("2. Ürün fiyatını girin (TL):");
            decimal fiyat2 = Convert.ToDecimal(Console.ReadLine());

            Urun urun2 = new Urun(ad2, fiyat2);

            Console.WriteLine("2. Ürün için indirim oranını girin (%):");
            decimal indirim2 = Convert.ToDecimal(Console.ReadLine());
            urun2.Indirim = indirim2; // İndirim oranını ayarla

            // İkinci ürün bilgilerini ekrana yazdır
            Console.WriteLine("\n2. Ürün Bilgileri:");
            Console.WriteLine($"Ürün: {urun2.Ad}");
            Console.WriteLine($"Fiyat: {urun2.Fiyat} TL");
            Console.WriteLine($"İndirimli Fiyat: {urun2.IndirimliFiyat()} TL");
        }
        catch (ArgumentOutOfRangeException e)
        {
            Console.WriteLine($"Hata: {e.Message}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Geçersiz giriş! Lütfen sayısal bir değer girin.");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Beklenmeyen bir hata oluştu: {e.Message}");
        }
    }
}

