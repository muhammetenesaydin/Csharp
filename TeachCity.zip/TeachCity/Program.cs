﻿using System;
using System.Collections.Generic;

namespace RobotRescueGame
{
    class Program
    {
        static int[,] GRID;
        static int ROWS, COLS;

        // Robot sınıfı
        class Robot
        {
            public string Name { get; set; }
            public Tuple<int, int> Position { get; set; }
            public List<Tuple<int, int>> Rescued { get; set; }

            public Robot(string name, Tuple<int, int> position)
            {
                Name = name;
                Position = position;
                Rescued = new List<Tuple<int, int>>();
            }
        }

        static void Main(string[] args)
        {
            // 1. Matris boyutunun kullanıcıdan alınması
            Console.Write("Matrisin boyutunu girin (n): ");
            int n = int.Parse(Console.ReadLine());
            ROWS = COLS = n;
            GRID = new int[ROWS, COLS];

            // 2. Matrisin rastgele oluşturulması
            Random rand = new Random();
            Console.WriteLine("\nOluşturulan Matris:");
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    GRID[i, j] = rand.Next(2); // 0 veya 1
                    Console.Write(GRID[i, j] + " ");
                }
                Console.WriteLine();
            }

            // 3. Robotların konumlarının kullanıcıdan alınması
            List<Robot> robots = new List<Robot>();
            for (int i = 1; i <= 3; i++)
            {
                Console.Write($"\nRobot {i} için başlangıç pozisyonunu (i, j) formatında girin: ");
                string[] input = Console.ReadLine().Split(',');
                int row = int.Parse(input[0]);
                int col = int.Parse(input[1]);

                if (row >= 0 && row < ROWS && col >= 0 && col < COLS && GRID[row, col] == 1)
                {
                    robots.Add(new Robot($"Robot{i}", Tuple.Create(row, col)));
                }
                else
                {
                    Console.WriteLine("Geçersiz pozisyon, lütfen geçerli bir pozisyon girin.");
                    i--; // Geçerli bir pozisyon girene kadar yeniden iste
                }
            }

            // Robotların kurtarabileceği düğümleri bulma
            Dictionary<string, List<Tuple<int, int>>> rescueMap = new Dictionary<string, List<Tuple<int, int>>>();
            foreach (var robot in robots)
            {
                List<Tuple<int, int>> rescued = new List<Tuple<int, int>>();
                HashSet<Tuple<int, int>> visited = new HashSet<Tuple<int, int>>();
                DFS(robot, robot.Position, visited, rescued);
                rescueMap[robot.Name] = rescued;
            }

            // Çakışmaları önlemek için robotların kurtardığı düğümleri ayarlama
            Dictionary<string, List<Tuple<int, int>>> finalRescue = new Dictionary<string, List<Tuple<int, int>>>();
            HashSet<Tuple<int, int>> taken = new HashSet<Tuple<int, int>>();

            foreach (var robot in robots)
            {
                finalRescue[robot.Name] = new List<Tuple<int, int>>();
                foreach (var pos in rescueMap[robot.Name])
                {
                    if (!taken.Contains(pos) && finalRescue[robot.Name].Count < GetMaxRescue(robot.Name))
                    {
                        finalRescue[robot.Name].Add(pos);
                        taken.Add(pos);
                    }
                }
            }

            // Sonuçları robotlara atama
            foreach (var robot in robots)
            {
                robot.Rescued = finalRescue[robot.Name];
            }

            // Sonuçları ekrana yazdırma
            Console.WriteLine("\nRobotların Kurtardığı Düğümler:");
            foreach (var robot in robots)
            {
                Console.Write($"{robot.Name}: ");
                foreach (var pos in robot.Rescued)
                {
                    Console.Write($"({pos.Item1}, {pos.Item2}) ");
                }
                Console.WriteLine($"- Toplam: {robot.Rescued.Count} düğüm");
            }

            // Grid üzerinde kurtarılan düğümleri gösterme
            string[,] displayGrid = new string[ROWS, COLS];
            for (int i = 0; i < ROWS; i++)
                for (int j = 0; j < COLS; j++)
                    displayGrid[i, j] = GRID[i, j].ToString();

            foreach (var robot in robots)
            {
                foreach (var pos in robot.Rescued)
                {
                    displayGrid[pos.Item1, pos.Item2] = "R";
                }
            }

            Console.WriteLine("\nKurtarılan Düğümlerle Güncellenmiş Grid:");
            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    Console.Write(displayGrid[i, j] + " ");
                }
                Console.WriteLine();
            }

            // Programı kapatmak için bir tuşa basılmasını bekleme
            Console.WriteLine("\nÇıkmak için herhangi bir tuşa basın...");
            Console.ReadKey();
        }

        // Robotun maksimum kurtarabileceği düğüm sayısı
        static int GetMaxRescue(string robotName)
        {
            switch (robotName)
            {
                case "Robot1":
                    return 4;
                case "Robot2":
                    return 3;
                case "Robot3":
                    return 1;
                default:
                    return 0;
            }
        }

        // DFS algoritması ile robotun kurtarabileceği düğümleri bulma
        static void DFS(Robot robot, Tuple<int, int> pos, HashSet<Tuple<int, int>> visited, List<Tuple<int, int>> rescued)
        {
            if (rescued.Count >= GetMaxRescue(robot.Name))
                return;

            if (IsValid(pos, visited))
            {
                visited.Add(pos);
                rescued.Add(pos);

                foreach (var neighbor in GetNeighbors(pos))
                {
                    DFS(robot, neighbor, visited, rescued);
                    if (rescued.Count >= GetMaxRescue(robot.Name))
                        break;
                }
            }
        }

        // Pozisyonun geçerli olup olmadığını kontrol etme
        static bool IsValid(Tuple<int, int> pos, HashSet<Tuple<int, int>> visited)
        {
            int row = pos.Item1;
            int col = pos.Item2;
            return row >= 0 && row < ROWS && col >= 0 && col < COLS && GRID[row, col] == 1 && !visited.Contains(pos);
        }

        // Komşu hücreleri alma (yukarı, aşağı, sol, sağ)
        static List<Tuple<int, int>> GetNeighbors(Tuple<int, int> pos)
        {
            List<Tuple<int, int>> neighbors = new List<Tuple<int, int>>();
            int row = pos.Item1;
            int col = pos.Item2;

            neighbors.Add(Tuple.Create(row - 1, col)); // Yukarı
            neighbors.Add(Tuple.Create(row + 1, col)); // Aşağı
            neighbors.Add(Tuple.Create(row, col - 1)); // Sol
            neighbors.Add(Tuple.Create(row, col + 1)); // Sağ

            // Filtreleme: Geçersiz pozisyonları çıkarma
            neighbors = neighbors.FindAll(n =>
                n.Item1 >= 0 && n.Item1 < ROWS &&
                n.Item2 >= 0 && n.Item2 < COLS &&
                GRID[n.Item1, n.Item2] == 1);

            return neighbors;
        }
    }
}
